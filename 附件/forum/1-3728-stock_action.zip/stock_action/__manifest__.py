# -*- coding: utf-8 -*-
# Part of Odoo. See LICENSE file for full copyright and licensing details.

{
    'name': 'Inventory',
    'version': '1.1',
    'summary': 'Manage your stock and logistics activities',
    'website': 'https://www.odoo.com/app/inventory',
    'depends': ['stock'],
    'category': 'Inventory/Inventory',
    'author': "OSCG",
    'website': "https://www.oscg.cn",
    
    'data': [
        
    ],
    
    'license': 'LGPL-3',
}
