# -*- encoding:utf-8 -*-
{
    "name": "bom_attribute_configure",
    'license': 'LGPL-3',
    "author": "OSCG", 
    "website": "http://www.oscg.cn",
    "depends": [
        "mrp","product","sale",
        'web',
    ],
    "data": [
        "security/ir.model.access.csv",
        "views/mrp_bom.xml",
        "views/product_attribute.xml",
        "views/product_product.xml",
        "views/product_template.xml",
        "views/product_category.xml",
        "views/mrp_bom_attribute_configure_line.xml",
        "views/bom_line_position.xml",
    ],
    "installable": True,
}
