# -*- coding: utf-8 -*-
# Part of Odoo. See LICENSE file for full copyright and licensing details.
from werkzeug import urls

from odoo import api, fields, models
from odoo.http import request
from odoo.tools.json import scriptsafe as json_scriptsafe


class ProductAttributeValue(models.Model):
    _inherit = 'product.attribute.value'

    type = fields.Selection(related='attribute_id.type',store=True)

