from odoo import api, fields,models, tools
from collections import defaultdict
import itertools
from odoo.osv import expression
import re


class ProductTemplate2(models.Model):
    _inherit = "product.category"
    
    CATEGORY_SELECTION = [
        ('good', '制造商品'),
        ('purchase_good', '成品'),
        ('fabric', '面料'),
        ('a_assistant', '高值辅料'),
        ('b_assistant', '低值辅料'),
        ('packaging', '包装料'),
        ('other', '其他'),
        ('choose', '请选择'),
    ]
    category_category = fields.Selection(CATEGORY_SELECTION, string="产品类别", default="choose", required=True)
    # wastage = fields.Float(string='损耗%')