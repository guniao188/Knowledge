from odoo import api, fields,models, tools
from collections import defaultdict
import itertools
from odoo.osv import expression
import re

class ProductTemplate(models.Model):
    _inherit = "product.template"
    
    second_uom_id = fields.Many2one('uom.uom','用量单位')
    accessory_uom_rate = fields.Float('转换比例')
    gram_weight = fields.Many2one('product.attribute.value',string = '克重',domain="[('type', '=', 'gram_weight')]")
    wastage = fields.Float(string='损耗%', store=True, readonly=False, copy=True)
    real_gram_weight = fields.Float(string='克重', compute='_compute_real_gram_weight')
    category_category = fields.Selection(related='categ_id.category_category', string='产品类别', store=True)
    second_uom_white_list = fields.Many2many('uom.uom', '第二单位白名单', compute='_compute_second_uom_white_list')



    def _compute_real_gram_weight(self):
        for product in self:
            pattern = r'\d+(\.\d+)?'
            if product.gram_weight.name:
                product.real_gram_weight = (re.search(pattern, str(product.gram_weight.name))  or 0.00).group()
            else:
                product.real_gram_weight = False

    def _compute_second_uom_white_list(selfs):
        for product in selfs:
            product.second_uom_white_list = selfs.env.ref('uom.product_uom_meter') | product.uom_id

    @api.onchange('uom_id')
    def _onchange_uom_id_change_second_uom(self):
        if self.category_category != 'fabric':
            self.second_uom_id = self.uom_id.id

    @api.model
    def create(cls, values):
        if not values.get('second_uom_id'):
            values['second_uom_id'] = values.get('uom_id')
        return super().create(values)

    def action_set_attribute_value_sequences(selfs):
        for self in selfs:
            color_line = self.attribute_line_ids.filtered(lambda l: l.attribute_id.type == 'color')
            color_sequence = set(color_line.product_template_value_ids.mapped('sequence'))
            if color_sequence == {False}:
                max_color_sequence = 10
            else:
                max_color_sequence = max(color_sequence)
            for i, color_value in enumerate(color_line.product_template_value_ids.filtered(lambda l: not l.sequence or l.sequence == 0)):
                    color_value.sequence = max_color_sequence + i
            size_line = self.attribute_line_ids.filtered(lambda l: l.attribute_id.type == 'size')
            size_sequence = set(size_line.product_template_value_ids.mapped('sequence'))
            if size_sequence == {False}:
                max_size_sequence = 30
            else:
                max_size_sequence = max(size_sequence)
            for i, size_value in enumerate(size_line.product_template_value_ids.filtered(lambda l: not l.sequence or l.sequence == 0)):
                size_value.sequence = max_size_sequence + i