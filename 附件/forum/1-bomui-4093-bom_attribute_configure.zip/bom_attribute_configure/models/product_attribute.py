# -*- coding: utf-8 -*-
# Part of Odoo. See LICENSE file for full copyright and licensing details.
from werkzeug import urls

from odoo import api, fields, models
from odoo.exceptions import UserError


class ProductAttribute(models.Model):
    _inherit = 'product.attribute'

    type = fields.Selection([('color','颜色'),('size','尺寸'),('gram_weight','克重')],'类别')

    @api.constrains('type')
    def check_unique_type(selfs):
        for self in selfs:
            if self.type and selfs.search_count([('type','=','gram_weight')]) > 1:
                raise UserError('已存在克重属性')