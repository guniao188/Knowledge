# -*- coding: utf-8 -*-
# Part of Odoo. See LICENSE file for full copyright and licensing details.
from werkzeug import urls

from odoo import api, fields, models
from odoo.http import request
from odoo.tools.json import scriptsafe as json_scriptsafe


class ProductTemplateAttributeValue(models.Model):
    _inherit = 'product.template.attribute.value'

    type = fields.Selection(related='attribute_id.type')
    sequence = fields.Integer('序号')

    @api.depends('attribute_id')
    def _compute_display_name(selfs):
        if not selfs._context.get('only_show_attribute_value'):
            super()._compute_display_name()

        for self in selfs:
            self.display_name = self.name

    @api.model
    def create(cls, values):
        self = super().create(values)
        if not self.sequence and self.type in ['color','size']:
            all_values = cls.search([
                ('attribute_line_id','=',self.attribute_line_id.id), ('id','!=',self.id)
            ])
            if all_values:
                self.sequence = max(all_values.mapped('sequence')) + 1
            else:
                self.sequence = self.type == 'color' and 10 or 30
        return self