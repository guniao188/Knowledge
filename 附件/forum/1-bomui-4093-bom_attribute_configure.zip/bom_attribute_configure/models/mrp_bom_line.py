# -*- encoding: utf-8 -*-
from odoo.tools import float_is_zero, float_compare, float_round
from odoo import api, models, fields
from odoo.exceptions import UserError, ValidationError
from dateutil.relativedelta import relativedelta

class MrpBomLine(models.Model):
    _inherit = 'mrp.bom.line'

    confirmed = fields.Boolean(string='已确认', default=False, copy=False)
    has_planed = fields.Boolean(string='已跑MRP运算', default=False, copy=False)
    configure_line_id = fields.Many2one('mrp.bom.attribute.configure.line',)
    position_name = fields.Char('部位')
    position_id = fields.Many2one('bom.line.position',string='排序',)


    def action_bom_line_confirmed(selfs):
        for self in selfs:
            self.confirmed = True

