from odoo import api, fields,models, tools
import re



class ProductProduct(models.Model):
    _inherit = "product.product"

    product_template_variant_value_ids = fields.Many2many('product.template.attribute.value',
                                                          domain=[('attribute_line_id.value_count', '>', 0)])
    def _compute_has_color_size_value(selfs):
        for self in selfs:
            self.has_color_size_value = not ({'color','size'} - set(self.product_template_variant_value_ids.mapped('type')))
    has_color_size_value = fields.Boolean(compute='_compute_has_color_size_value')

    def _compute_larghezza(selfs):
        for self in selfs:
            size = self.product_template_variant_value_ids.filtered(
                lambda l: l.attribute_id.type == 'size')[:1].name
            self.larghezza = size
    larghezza = fields.Char('门幅', compute='_compute_larghezza')

    def _compute_real_larghezza(selfs):
        Pattern = r'\d+(\.\d+)?'
        for self in selfs:
            if self.larghezza:
                self.real_larghezza = (re.search(Pattern, str(self.larghezza)) or 0.00).group()
            else:
                self.real_larghezza = False
    real_larghezza = fields.Float('门幅', compute='_compute_real_larghezza')


    @api.onchange('uom_id')
    def _onchange_uom_id_change_second_uom(self):
        if self.category_category != 'fabric':
            self.second_uom_id = self.uom_id.id
