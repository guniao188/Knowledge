from odoo import api, fields, models
from odoo.exceptions import UserError



class PurchaseNote(models.Model):
    _name = "bom.line.position"
    _description = "BOM排序"
    _rec_name = 'name'
    _order = 'sequence'
    
    name = fields.Char('排序名称', required=True, translate=True)
    sequence = fields.Integer('Sequence', default=10)
    active = fields.Boolean('启用', default=True,)

