# -*- coding: utf-8 -*-
# Part of Odoo. See LICENSE file for full copyright and licensing details.
from werkzeug import urls

from odoo import api, fields, models
import re
from odoo.exceptions import UserError

class MrpBomAttributeConfigureLine(models.Model):
    _name = 'mrp.bom.attribute.configure.line'
    _description = '二开BOM-配置行可以配色配码，用于快速生成不同颜色尺码的组件'
    _order = 'bom_id, sequence asc, id asc'

    @api.depends('product_template_id')
    def _compute_wastage(selfs):
        for self in selfs:
            self.wastage = self.product_template_id.wastage
#            
    wastage = fields.Float(string='损耗%',compute='_compute_wastage',store=True,readonly=False,copy=True)
    origin_configure_line = fields.Many2one('mrp.bom.attribute.configure.line', string='原行', copy=True)
    bom_id = fields.Many2one('mrp.bom',string='BOM')
    sequence = fields.Integer('序号',default=100)
    bom_product_template_id = fields.Many2one(related='bom_id.product_tmpl_id',string='款式编号')
    bom_code = fields.Char(related='bom_id.code',string='bom参考号')
    sale_id = fields.Many2one(related='bom_id.sale_id',string='销售订单')
    sale_color_attribute_value_sequences = fields.Char(related='bom_id.sale_color_attribute_value_sequences')
    color_attribute_values_count = fields.Integer(related='bom_id.color_attribute_values_count')
    sale_size_attribute_value_sequences = fields.Char(related='bom_id.sale_size_attribute_value_sequences')
    size_attribute_values_count = fields.Integer(related='bom_id.size_attribute_values_count')
    bom_line_id = fields.One2many('mrp.bom.line', 'configure_line_id', copy=False)
    supplied_by_subsupplier = fields.Boolean('工厂备货',copy=False,default=False)
    product_category_id = fields.Many2one(related='product_template_id.categ_id', string='类别')
    product_template_id = fields.Many2one('product.template', '产品')
    product_uom_id = fields.Many2one(related='product_template_id.uom_id', string='单位')
    second_uom_id = fields.Many2one(related='product_template_id.second_uom_id', string='单位')
    garment_qty = fields.Integer(string='成衣数量', default=1)
    materiel_qty = fields.Integer(string='物料数量', default=0, )
    is_readonly = fields.Boolean()
    is_choose = fields.Boolean(copy=False)
    has_create_bom_line = fields.Boolean(copy=False)
    company_id = fields.Many2one(related='bom_id.company_id', store=True, index=True, readonly=True)
    position_name = fields.Char('部位')
    position_id = fields.Many2one('bom.line.position',string='排序',)
    allowed_operation_ids = fields.One2many('mrp.routing.workcenter', related='bom_id.operation_ids')
    operation_id = fields.Many2one('mrp.routing.workcenter', '消耗在作业', check_company=True,domain="[('id', 'in', allowed_operation_ids)]",)
    value10_id = fields.Many2one('product.template.attribute.value', '#10')
    color_1_1_image_1920 = fields.Image("Variant Image", max_width=1920, max_height=1920,copy=True)
    color_1_2_image_1920 = fields.Image("Variant Image", max_width=1920, max_height=1920,copy=True)
    color_1_3_image_1920 = fields.Image("Variant Image", max_width=1920, max_height=1920,copy=True)
    color_1_1_image_remark = fields.Text("备注")
    color_1_2_image_remark = fields.Text("备注")
    color_1_3_image_remark = fields.Text("备注")
    value11_id = fields.Many2one('product.template.attribute.value', '#11')
    color_2_1_image_1920 = fields.Image("Variant Image", max_width=1920, max_height=1920,copy=True)
    color_2_2_image_1920 = fields.Image("Variant Image", max_width=1920, max_height=1920,copy=True)
    color_2_3_image_1920 = fields.Image("Variant Image", max_width=1920, max_height=1920,copy=True)
    color_2_1_image_remark = fields.Text("备注")
    color_2_2_image_remark = fields.Text("备注")
    color_2_3_image_remark = fields.Text("备注")
    value12_id = fields.Many2one('product.template.attribute.value', '#12')
    color_3_1_image_1920 = fields.Image("Variant Image", max_width=1920, max_height=1920,copy=True)
    color_3_2_image_1920 = fields.Image("Variant Image", max_width=1920, max_height=1920,copy=True)
    color_3_3_image_1920 = fields.Image("Variant Image", max_width=1920, max_height=1920,copy=True)
    color_3_1_image_remark = fields.Text("备注")
    color_3_2_image_remark = fields.Text("备注")
    color_3_3_image_remark = fields.Text("备注")
    value13_id = fields.Many2one('product.template.attribute.value', '#13')
    color_4_1_image_1920 = fields.Image("Variant Image", max_width=1920, max_height=1920,copy=True)
    color_4_2_image_1920 = fields.Image("Variant Image", max_width=1920, max_height=1920,copy=True)
    color_4_3_image_1920 = fields.Image("Variant Image", max_width=1920, max_height=1920,copy=True)
    color_4_1_image_remark = fields.Text("备注")
    color_4_2_image_remark = fields.Text("备注")
    color_4_3_image_remark = fields.Text("备注")
    value14_id = fields.Many2one('product.template.attribute.value', '#14')
    color_5_1_image_1920 = fields.Image("Variant Image", max_width=1920, max_height=1920,copy=True)
    color_5_2_image_1920 = fields.Image("Variant Image", max_width=1920, max_height=1920,copy=True)
    color_5_3_image_1920 = fields.Image("Variant Image", max_width=1920, max_height=1920,copy=True)
    color_5_1_image_remark = fields.Text("备注")
    color_5_2_image_remark = fields.Text("备注")
    color_5_3_image_remark = fields.Text("备注")
    value15_id = fields.Many2one('product.template.attribute.value', '#15')
    color_6_1_image_1920 = fields.Image("Variant Image", max_width=1920, max_height=1920,copy=True)
    color_6_2_image_1920 = fields.Image("Variant Image", max_width=1920, max_height=1920,copy=True)
    color_6_3_image_1920 = fields.Image("Variant Image", max_width=1920, max_height=1920,copy=True)
    color_6_1_image_remark = fields.Text("备注")
    color_6_2_image_remark = fields.Text("备注")
    color_6_3_image_remark = fields.Text("备注")
    value16_id = fields.Many2one('product.template.attribute.value', '#16')
    color_7_1_image_1920 = fields.Image("Variant Image", max_width=1920, max_height=1920,copy=True)
    color_7_2_image_1920 = fields.Image("Variant Image", max_width=1920, max_height=1920,copy=True)
    color_7_3_image_1920 = fields.Image("Variant Image", max_width=1920, max_height=1920,copy=True)
    color_7_1_image_remark = fields.Text("备注")
    color_7_2_image_remark = fields.Text("备注")
    color_7_3_image_remark = fields.Text("备注")
    value17_id = fields.Many2one('product.template.attribute.value', '#17')
    color_8_1_image_1920 = fields.Image("Variant Image", max_width=1920, max_height=1920,copy=True)
    color_8_2_image_1920 = fields.Image("Variant Image", max_width=1920, max_height=1920,copy=True)
    color_8_3_image_1920 = fields.Image("Variant Image", max_width=1920, max_height=1920,copy=True)
    color_8_1_image_remark = fields.Text("备注")
    color_8_2_image_remark = fields.Text("备注")
    color_8_3_image_remark = fields.Text("备注")
    value18_id = fields.Many2one('product.template.attribute.value', '#18')
    color_9_1_image_1920 = fields.Image("Variant Image", max_width=1920, max_height=1920,copy=True)
    color_9_2_image_1920 = fields.Image("Variant Image", max_width=1920, max_height=1920,copy=True)
    color_9_3_image_1920 = fields.Image("Variant Image", max_width=1920, max_height=1920,copy=True)
    color_9_1_image_remark = fields.Text("备注")
    color_9_2_image_remark = fields.Text("备注")
    color_9_3_image_remark = fields.Text("备注")
    value19_id = fields.Many2one('product.template.attribute.value', '#19')
    color_10_1_image_1920 = fields.Image("Variant Image", max_width=1920, max_height=1920,copy=True)
    color_10_2_image_1920 = fields.Image("Variant Image", max_width=1920, max_height=1920,copy=True)
    color_10_3_image_1920 = fields.Image("Variant Image", max_width=1920, max_height=1920,copy=True)
    color_10_1_image_remark = fields.Text("备注")
    color_10_2_image_remark = fields.Text("备注")
    color_10_3_image_remark = fields.Text("备注")
    value20_id = fields.Many2one('product.template.attribute.value', '#20')
    color_11_1_image_1920 = fields.Image("Variant Image", max_width=1920, max_height=1920,copy=True)
    color_11_2_image_1920 = fields.Image("Variant Image", max_width=1920, max_height=1920,copy=True)
    color_11_3_image_1920 = fields.Image("Variant Image", max_width=1920, max_height=1920,copy=True)
    color_11_1_image_remark = fields.Text("备注")
    color_11_2_image_remark = fields.Text("备注")
    color_11_3_image_remark = fields.Text("备注")
    value21_id = fields.Many2one('product.template.attribute.value', '#21')
    color_12_1_image_1920 = fields.Image("Variant Image", max_width=1920, max_height=1920,copy=True)
    color_12_2_image_1920 = fields.Image("Variant Image", max_width=1920, max_height=1920,copy=True)
    color_12_3_image_1920 = fields.Image("Variant Image", max_width=1920, max_height=1920,copy=True)
    color_12_1_image_remark = fields.Text("备注")
    color_12_2_image_remark = fields.Text("备注")
    color_12_3_image_remark = fields.Text("备注")
    value22_id = fields.Many2one('product.template.attribute.value', '#22')
    color_13_1_image_1920 = fields.Image("Variant Image", max_width=1920, max_height=1920,copy=True)
    color_13_2_image_1920 = fields.Image("Variant Image", max_width=1920, max_height=1920,copy=True)
    color_13_3_image_1920 = fields.Image("Variant Image", max_width=1920, max_height=1920,copy=True)
    color_13_1_image_remark = fields.Text("备注")
    color_13_2_image_remark = fields.Text("备注")
    color_13_3_image_remark = fields.Text("备注")
    value23_id = fields.Many2one('product.template.attribute.value', '#23')
    color_14_1_image_1920 = fields.Image("Variant Image", max_width=1920, max_height=1920,copy=True)
    color_14_2_image_1920 = fields.Image("Variant Image", max_width=1920, max_height=1920,copy=True)
    color_14_3_image_1920 = fields.Image("Variant Image", max_width=1920, max_height=1920,copy=True)
    color_14_1_image_remark = fields.Text("备注")
    color_14_2_image_remark = fields.Text("备注")
    color_14_3_image_remark = fields.Text("备注")
    value24_id = fields.Many2one('product.template.attribute.value', '#24')
    color_15_1_image_1920 = fields.Image("Variant Image", max_width=1920, max_height=1920,copy=True)
    color_15_2_image_1920 = fields.Image("Variant Image", max_width=1920, max_height=1920,copy=True)
    color_15_3_image_1920 = fields.Image("Variant Image", max_width=1920, max_height=1920,copy=True)
    color_15_1_image_remark = fields.Text("备注")
    color_15_2_image_remark = fields.Text("备注")
    color_15_3_image_remark = fields.Text("备注")
    value25_id = fields.Many2one('product.template.attribute.value', '#25')
    value26_id = fields.Many2one('product.template.attribute.value', '#26')
    value27_id = fields.Many2one('product.template.attribute.value', '#27')
    value28_id = fields.Many2one('product.template.attribute.value', '#28')
    value29_id = fields.Many2one('product.template.attribute.value', '#29')

    value30_id = fields.Many2one('product.template.attribute.value', '#30')
    value31_id = fields.Many2one('product.template.attribute.value', '#31')
    value32_id = fields.Many2one('product.template.attribute.value', '#32')
    value33_id = fields.Many2one('product.template.attribute.value', '#33')
    value34_id = fields.Many2one('product.template.attribute.value', '#34')
    value35_id = fields.Many2one('product.template.attribute.value', '#35')
    value36_id = fields.Many2one('product.template.attribute.value', '#36')
    value37_id = fields.Many2one('product.template.attribute.value', '#37')
    value38_id = fields.Many2one('product.template.attribute.value', '#38')
    value39_id = fields.Many2one('product.template.attribute.value', '#39')
    value40_id = fields.Many2one('product.template.attribute.value', '#40')
    value41_id = fields.Many2one('product.template.attribute.value', '#41')
    value42_id = fields.Many2one('product.template.attribute.value', '#42')
    value43_id = fields.Many2one('product.template.attribute.value', '#43')
    value44_id = fields.Many2one('product.template.attribute.value', '#44')
    value45_id = fields.Many2one('product.template.attribute.value', '#45')
    value46_id = fields.Many2one('product.template.attribute.value', '#46')
    value47_id = fields.Many2one('product.template.attribute.value', '#47')
    value48_id = fields.Many2one('product.template.attribute.value', '#48')
    value49_id = fields.Many2one('product.template.attribute.value', '#49')

    image_count = fields.Integer(string='图片数量', compute='_compute_image_count')

    confirmed = fields.Boolean(string='业务确认', default=False, copy=False)
    confirmed_date = fields.Datetime(string='业务确认时间',copy=False)
    confirmed_user_id = fields.Many2one('res.users',string='业务确认人',copy=False)
    qty_confirmed = fields.Boolean(string='技术确认', default=False, copy=False)
    qty_confirmed_date = fields.Datetime(string='技术确认时间', copy=False)
    qty_confirmed_user_id = fields.Many2one('res.users',string='技术确认人',copy=False)

    @api.depends('color_1_1_image_1920', 'color_1_2_image_1920', 'color_1_3_image_1920',
                 'color_2_1_image_1920', 'color_2_2_image_1920', 'color_2_3_image_1920',
                 'color_3_1_image_1920', 'color_3_2_image_1920', 'color_3_3_image_1920',
                 'color_4_1_image_1920', 'color_4_2_image_1920', 'color_4_3_image_1920',
                 'color_5_1_image_1920', 'color_5_2_image_1920', 'color_5_3_image_1920',
                 'color_6_1_image_1920', 'color_6_2_image_1920', 'color_6_3_image_1920',
                 'color_7_1_image_1920', 'color_7_2_image_1920', 'color_7_3_image_1920',
                 'color_8_1_image_1920', 'color_8_2_image_1920', 'color_8_3_image_1920',
                 'color_9_1_image_1920', 'color_9_2_image_1920', 'color_9_3_image_1920',
                 'color_10_1_image_1920', 'color_10_2_image_1920', 'color_10_3_image_1920',
                 'color_11_1_image_1920', 'color_11_2_image_1920', 'color_11_3_image_1920',
                 'color_12_1_image_1920', 'color_12_2_image_1920', 'color_12_3_image_1920',
                 'color_13_1_image_1920', 'color_13_2_image_1920', 'color_13_3_image_1920',
                 'color_14_1_image_1920', 'color_14_2_image_1920', 'color_14_3_image_1920',
                 'color_15_1_image_1920', 'color_15_2_image_1920', 'color_15_3_image_1920',
                 )
    def _compute_image_count(self):
        for data in self:
            num = 0
            if data.color_1_1_image_1920:
                num = num + 1
            if data.color_1_2_image_1920:
                num = num + 1
            if data.color_1_3_image_1920:
                num = num + 1
            if data.color_2_1_image_1920:
                num = num + 1
            if data.color_2_2_image_1920:
                num = num + 1
            if data.color_2_3_image_1920:
                num = num + 1
            if data.color_3_1_image_1920:
                num = num + 1
            if data.color_3_2_image_1920:
                num = num + 1
            if data.color_3_3_image_1920:
                num = num + 1
            if data.color_4_1_image_1920:
                num = num + 1
            if data.color_4_2_image_1920:
                num = num + 1
            if data.color_4_3_image_1920:
                num = num + 1
            if data.color_5_1_image_1920:
                num = num + 1
            if data.color_5_2_image_1920:
                num = num + 1
            if data.color_5_3_image_1920:
                num = num + 1
            if data.color_6_1_image_1920:
                num = num + 1
            if data.color_6_2_image_1920:
                num = num + 1
            if data.color_6_3_image_1920:
                num = num + 1
            if data.color_7_1_image_1920:
                num = num + 1
            if data.color_7_2_image_1920:
                num = num + 1
            if data.color_7_3_image_1920:
                num = num + 1
            if data.color_8_1_image_1920:
                num = num + 1
            if data.color_8_2_image_1920:
                num = num + 1
            if data.color_8_3_image_1920:
                num = num + 1
            if data.color_9_1_image_1920:
                num = num + 1
            if data.color_9_2_image_1920:
                num = num + 1
            if data.color_9_3_image_1920:
                num = num + 1
            if data.color_10_1_image_1920:
                num = num + 1
            if data.color_10_2_image_1920:
                num = num + 1
            if data.color_10_3_image_1920:
                num = num + 1
            if data.color_11_1_image_1920:
                num = num + 1
            if data.color_11_2_image_1920:
                num = num + 1
            if data.color_11_3_image_1920:
                num = num + 1
            if data.color_12_1_image_1920:
                num = num + 1
            if data.color_12_2_image_1920:
                num = num + 1
            if data.color_12_3_image_1920:
                num = num + 1
            if data.color_13_1_image_1920:
                num = num + 1
            if data.color_13_2_image_1920:
                num = num + 1
            if data.color_13_3_image_1920:
                num = num + 1
            if data.color_14_1_image_1920:
                num = num + 1
            if data.color_14_2_image_1920:
                num = num + 1
            if data.color_14_3_image_1920:
                num = num + 1
            if data.color_15_1_image_1920:
                num = num + 1
            if data.color_15_2_image_1920:
                num = num + 1
            if data.color_15_3_image_1920:
                num = num + 1
            data.image_count = num

    def _compute_real_qty(selfs):
        Pattern1 = r'\d+(\.\d+)?'
        Pattern2 = r'\d?'
        for self in selfs:
            product_template =self.product_template_id
            factor = product_template.real_gram_weight or 1.00
            for i in range(20):
                _real_qty = self[f'qty{i}']   / (product_template.accessory_uom_rate or 1.00)
#                if self.product_category_id.is_packaging_material_mrp and _real_qty != 0.00:
#                    _real_qty = 1 / _real_qty
                if all([
                    product_template.category_category == 'fabric',
                    self.product_uom_id != self.second_uom_id,
                    product_template.accessory_uom_rate == 0.00
                ]):
                    factor_2_char = self[f'value{30+i}_id'].name or ''
                    search_result_1 = re.search(Pattern1, str(factor_2_char))
                    search_result_2 = re.search(Pattern2, str(factor_2_char))
#                    raise UserError([search_result_1,search_result_2])
                    if search_result_1 == search_result_2 :
                        factor_2 = search_result_2 and float(search_result_1.group(1)) or 1.0
                    elif search_result_1 and search_result_1 != search_result_2:
                        factor_2 = search_result_1 and (float(search_result_1.group(1)) +float(search_result_2.group(0)) ) or 1.0

                    # {
                    #     'factor': '克重g/m2',
                    #     'factor_2': '门幅m'
                    #     '_real_qty': '用量（第二单位）',
                    # }
                    #
                    _real_qty *= round(factor * (factor_2) / 1000,3)
                self[f'real_qty{i}'] = _real_qty

    real_qty0 = fields.Float('*0',compute='_compute_real_qty')
    real_qty1 = fields.Float('*1',compute='_compute_real_qty')
    real_qty2 = fields.Float('*2',compute='_compute_real_qty')
    real_qty3 = fields.Float('*3',compute='_compute_real_qty')
    real_qty4 = fields.Float('*4',compute='_compute_real_qty')
    real_qty5 = fields.Float('*5',compute='_compute_real_qty')
    real_qty6 = fields.Float('*6',compute='_compute_real_qty')
    real_qty7 = fields.Float('*7',compute='_compute_real_qty')
    real_qty8 = fields.Float('*8',compute='_compute_real_qty')
    real_qty9 = fields.Float('*9',compute='_compute_real_qty')
    real_qty10 = fields.Float('*10',compute='_compute_real_qty')
    real_qty11 = fields.Float('*11',compute='_compute_real_qty')
    real_qty12 = fields.Float('*12',compute='_compute_real_qty')
    real_qty13 = fields.Float('*13',compute='_compute_real_qty')
    real_qty14 = fields.Float('*14',compute='_compute_real_qty')
    real_qty15 = fields.Float('*15',compute='_compute_real_qty')
    real_qty16 = fields.Float('*16',compute='_compute_real_qty')
    real_qty17 = fields.Float('*17',compute='_compute_real_qty')
    real_qty18 = fields.Float('*18',compute='_compute_real_qty')
    real_qty19 = fields.Float('*19',compute='_compute_real_qty')

    qty0 = fields.Float('*0',digits=(16, 6),)
    qty1 = fields.Float('*1',digits=(16, 6),)
    qty2 = fields.Float('*2',digits=(16, 6),)
    qty3 = fields.Float('*3',digits=(16, 6),)
    qty4 = fields.Float('*4',digits=(16, 6),)
    qty5 = fields.Float('*5',digits=(16, 6),)
    qty6 = fields.Float('*6',digits=(16, 6),)
    qty7 = fields.Float('*7',digits=(16, 6),)
    qty8 = fields.Float('*8',digits=(16, 6),)
    qty9 = fields.Float('*9',digits=(16, 6),)
    qty10 = fields.Float('*10',digits=(16, 6),)
    qty11 = fields.Float('*11',digits=(16, 6),)
    qty12 = fields.Float('*12',digits=(16, 6),)
    qty13 = fields.Float('*13',digits=(16, 6),)
    qty14 = fields.Float('*14',digits=(16, 6),)
    qty15 = fields.Float('*15',digits=(16, 6),)
    qty16 = fields.Float('*16',digits=(16, 6),)
    qty17 = fields.Float('*17',digits=(16, 6),)
    qty18 = fields.Float('*18',digits=(16, 6),)
    qty19 = fields.Float('*19',digits=(16, 6),)



    default_color_value_id = fields.Many2one('product.template.attribute.value', '颜色')
    default_size_value_id = fields.Many2one('product.template.attribute.value', '尺寸')

    default_qty = fields.Float('数量')

    @api.depends('qty0','qty1','qty2','qty3','qty4','qty5','qty6','qty7','qty8','qty9','qty10','qty11','qty12','qty13','qty14','qty15','qty16','qty17','qty18','qty19','default_qty','is_readonly')
    def _compute_is_zero_qty(selfs):
        for self in selfs:
            if (self.qty0 == self.qty1 == self.qty2 == self.qty3 == self.qty4 == self.qty5 == self.qty6 == self.qty7 == self.qty8 == self.qty9 ==self.qty10 == self.qty11 == self.qty12 == self.qty13 == self.qty14 == self.qty15 == self.qty16 == self.qty17 == self.qty18 == self.qty19 == self.default_qty == 0.00) and not self.is_readonly:
                self.is_zero_qty = True
            else:
                self.is_zero_qty = False
    is_zero_qty = fields.Boolean(copy=False,compute='_compute_is_zero_qty',store=True)

    @api.depends(*(['default_qty','is_readonly']+[f'qty{i}' for i in range(20)]))
    def _compute_is_same_qty(selfs):
        for self in selfs:
            self.is_same_qty = len(set([self[f'qty{i}'] for i in range(20) if self[f'qty{i}'] > 0.0]))==1 and not any([self[f'value{30+i}_id'] for i in range(20)])
    is_same_qty = fields.Boolean(copy=False,compute='_compute_is_same_qty',store=False)


    garment_color_1 = fields.Many2one('product.template.attribute.value', '成衣色组')
    garment_color_2 = fields.Many2one('product.template.attribute.value', '成衣色组')
    garment_color_3 = fields.Many2one('product.template.attribute.value', '成衣色组')
    garment_color_4 = fields.Many2one('product.template.attribute.value', '成衣色组')
    garment_color_5 = fields.Many2one('product.template.attribute.value', '成衣色组')
    garment_color_6 = fields.Many2one('product.template.attribute.value', '成衣色组')
    garment_color_7 = fields.Many2one('product.template.attribute.value', '成衣色组')
    garment_color_8 = fields.Many2one('product.template.attribute.value', '成衣色组')
    garment_color_9 = fields.Many2one('product.template.attribute.value', '成衣色组')
    garment_color_10 = fields.Many2one('product.template.attribute.value', '成衣色组')
    garment_color_11 = fields.Many2one('product.template.attribute.value', '成衣色组')
    garment_color_12 = fields.Many2one('product.template.attribute.value', '成衣色组')
    garment_color_13 = fields.Many2one('product.template.attribute.value', '成衣色组')
    garment_color_14 = fields.Many2one('product.template.attribute.value', '成衣色组')
    garment_color_15 = fields.Many2one('product.template.attribute.value', '成衣色组')

    @api.model
    def create(cls, values):
        selfs = super().create(values)
        for self in selfs:
            bom = self.bom_id
            line = bom.attribute_configure_line_ids.filtered(lambda l: l.product_template_id == bom.product_tmpl_id  and l.is_readonly == True)
            if line:
                self.garment_color_1 = line[0].value10_id.id
                self.garment_color_2 = line[0].value11_id.id
                self.garment_color_3 = line[0].value12_id.id
                self.garment_color_4 = line[0].value13_id.id
                self.garment_color_5 = line[0].value14_id.id
                self.garment_color_6 = line[0].value15_id.id
                self.garment_color_7 = line[0].value16_id.id
                self.garment_color_8 = line[0].value17_id.id
                self.garment_color_9 = line[0].value18_id.id
                self.garment_color_10 = line[0].value19_id.id
                self.garment_color_11 = line[0].value20_id.id
                self.garment_color_12 = line[0].value21_id.id
                self.garment_color_13 = line[0].value22_id.id
                self.garment_color_14 = line[0].value23_id.id
                self.garment_color_15 = line[0].value24_id.id
        return selfs


    @api.onchange('default_color_value_id')
    def onchange_from_default_color_value_id(self):
        template = self.bom_id.product_tmpl_id
        color_attribute_line = template.attribute_line_ids.filtered(lambda l: l.attribute_id.type == 'color')
        if self.default_color_value_id:
            for i in range(len(color_attribute_line.product_template_value_ids)):
                self.update({
                    f'value{10+i}_id': self.default_color_value_id.id
                })
        else:
            for i in range(len(color_attribute_line.product_template_value_ids)):
                self.update({
                    f'value{10+i}_id': False
                })

    @api.onchange('default_size_value_id')
    def onchange_from_default_size_value_id(self):
        if self.default_size_value_id:
            template = self.bom_id.product_tmpl_id
            size_attribute_line = template.attribute_line_ids.filtered(
                lambda l: l.attribute_id.type == 'size')
            for i in range(len(size_attribute_line.product_template_value_ids)):
                self.update({
                    f'value{30+i}_id': self.default_size_value_id.id
                })

    @api.onchange('default_qty')
    def onchange_from_default_qty(self):
        if self.default_qty:
            template = self.bom_id.product_tmpl_id
            size_attribute_line = template.attribute_line_ids.filtered(
                lambda l: l.attribute_id.type == 'size')
            for i in range(len(size_attribute_line.product_template_value_ids)):
                self.update({
                    f'qty{i}': self.default_qty
                })

    @api.onchange('product_template_id')
    def onchange_product_template_id(self):
        for i in range(15):
            self.update({f'value{10+i}_id': False,})
        for i in range(20):
            self.update({f'value{30+i}_id': False})

    def multi_action_bom_line_confirmed(selfs):
        for self in selfs:
            self = self.sudo()
            self.confirmed = not self.confirmed
            self.confirmed_date = fields.Datetime.now()
            self.confirmed_user_id = self.env.user.id
            if self.operation_id and self.operation_id not in self.bom_id.operation_ids:
                this_operation  = self.bom_id.operation_ids.filtered(lambda s: s.name == self.operation_id.name)  
                self.write({'operation_id':this_operation[-1:].id})


    def check_attributes(selfs):
        for self in selfs:
            for i in range(15):
                color_attribute = self[f'value{i+10}_id']
                if color_attribute and (color_attribute.product_tmpl_id != self.product_template_id or not color_attribute.ptav_active)  :
                    raise UserError("物料[%s]属性[%s]错误，色组[%s],请重新选择！"  %(self.product_template_id.name,color_attribute.name,i+1))
            for i in range(20):
                size_attribute = self[f'value{i+30}_id'] 
                if size_attribute and (size_attribute.product_tmpl_id != self.product_template_id or not size_attribute.ptav_active) :
                    raise UserError("物料[%s]属性[%s]错误，尺码组[%s],尺码所属物料[%s]请重新选择！"  %(self.product_template_id.name,size_attribute.name,i+1,size_attribute.product_tmpl_id.name))

    def check_qty(selfs):
        for self in selfs:
            if self.is_zero_qty:
                raise UserError("技术:物料[%s]没有填写用量,请检查!" %(self.product_template_id.name,))
    
    def action_qty_confirmed(selfs):
        for self in selfs:
            self = self.sudo()
            self.bom_line_id.action_bom_line_confirmed()
            self.qty_confirmed = True
            self.qty_confirmed_date = fields.Datetime.now()
            self.qty_confirmed_user_id = self.env.user.id

    def action_open_record(self):
        self.ensure_one()
        action = {
            'res_model': 'mrp.bom.attribute.configure.line',
            'type': 'ir.actions.act_window',
        }
        action.update({
            'view_mode': 'form',
            'res_id': self.id,
            'target':'new',
        })
        return action

    
    def action_open_self_mo(self):
        self.ensure_one()
        self.bom_id.this_attribute_configure_line_id = self.id
        if not self.bom_id.this_garment_attribute_configure_line_id:
            self.bom_id.this_garment_attribute_configure_line_id = self.bom_id.attribute_configure_line_ids.filtered(lambda l: l.is_readonly)[0].id
        action = {
            'res_model': 'mrp.bom',
            'type': 'ir.actions.act_window',
        }
        action.update({
            'view_mode': 'form',
            'res_id': self.bom_id.id,
            'target':'new',
            'context': {'this_line':self.id,'garment_line':self.bom_id.this_garment_attribute_configure_line_id.id,},
            'views': [[self.env.ref('bom_attribute_configure.mrp_bom_form_this_line_to_bom').id, 'form']],
        })
        return action


    def action_new_product(self):
        product_template = self.product_template_id
        name = product_template.origin_product_name or product_template.name
        product_template.origin_product_name = name
        target_product_template = product_template.copy({
            'name': name+ '[' + self.bom_id.sale_id.name + '/' + ( self.bom_id.product_tmpl_id.name) + ']',
            'seller_ids': [(0,0,seller.copy_data()[0]) for seller in product_template.seller_ids],
            'property_stock_production': product_template.property_stock_production.id,
        })

        new_values = {'product_template_id': target_product_template.id,}
        for i in range(10,45):
            product_template_attribute_value = self[f'value{i}_id']
            if not product_template_attribute_value:
                continue
            new_values.update({
                f'value{i}_id': target_product_template.attribute_line_ids.product_template_value_ids.filtered(
                    lambda ptv: ptv.product_attribute_value_id == product_template_attribute_value.product_attribute_value_id).id
            })
        self.write(new_values)


    show_all_color = fields.Boolean('显示所有颜色',default=False) 
    show_all_size = fields.Boolean('显示所有尺码',default=False) 

    def copy(self, default=None):
        res = super().copy(default)
        res.color_1_1_image_1920 = self.color_1_1_image_1920
        res.color_1_2_image_1920 = self.color_1_2_image_1920
        res.color_1_3_image_1920 = self.color_1_3_image_1920
        res.color_2_1_image_1920 = self.color_2_1_image_1920
        res.color_2_2_image_1920 = self.color_2_2_image_1920
        res.color_2_3_image_1920 = self.color_2_3_image_1920
        res.color_3_1_image_1920 = self.color_3_1_image_1920
        res.color_3_2_image_1920 = self.color_3_2_image_1920
        res.color_3_3_image_1920 = self.color_3_3_image_1920
        res.color_4_1_image_1920 = self.color_4_1_image_1920
        res.color_4_2_image_1920 = self.color_4_2_image_1920
        res.color_4_3_image_1920 = self.color_4_3_image_1920
        res.color_5_1_image_1920 = self.color_5_1_image_1920
        res.color_5_2_image_1920 = self.color_5_2_image_1920
        res.color_5_3_image_1920 = self.color_5_3_image_1920
        res.color_6_1_image_1920 = self.color_6_1_image_1920
        res.color_6_2_image_1920 = self.color_6_2_image_1920
        res.color_6_3_image_1920 = self.color_6_3_image_1920
        res.color_7_1_image_1920 = self.color_7_1_image_1920
        res.color_7_2_image_1920 = self.color_7_2_image_1920
        res.color_7_3_image_1920 = self.color_7_3_image_1920
        res.color_8_1_image_1920 = self.color_8_1_image_1920
        res.color_8_2_image_1920 = self.color_8_2_image_1920
        res.color_8_3_image_1920 = self.color_8_3_image_1920
        res.color_9_1_image_1920 = self.color_9_1_image_1920
        res.color_9_2_image_1920 = self.color_9_2_image_1920
        res.color_9_3_image_1920 = self.color_9_3_image_1920
        res.color_10_1_image_1920 = self.color_10_1_image_1920
        res.color_10_2_image_1920 = self.color_10_2_image_1920
        res.color_10_3_image_1920 = self.color_10_3_image_1920
        res.color_11_1_image_1920 = self.color_11_1_image_1920
        res.color_11_2_image_1920 = self.color_11_2_image_1920
        res.color_11_3_image_1920 = self.color_11_3_image_1920
        res.color_12_1_image_1920 = self.color_12_1_image_1920
        res.color_12_2_image_1920 = self.color_12_2_image_1920
        res.color_12_3_image_1920 = self.color_12_3_image_1920
        res.color_13_1_image_1920 = self.color_13_1_image_1920
        res.color_13_2_image_1920 = self.color_13_2_image_1920
        res.color_13_3_image_1920 = self.color_13_3_image_1920
        res.color_14_1_image_1920 = self.color_14_1_image_1920
        res.color_14_2_image_1920 = self.color_14_2_image_1920
        res.color_14_3_image_1920 = self.color_14_3_image_1920
        res.color_15_1_image_1920 = self.color_15_1_image_1920
        res.color_15_2_image_1920 = self.color_15_2_image_1920
        res.color_15_3_image_1920 = self.color_15_3_image_1920
        return res
        
    need_copy = fields.Boolean('下一单复制', default=True, copy=True) 