# -*- coding: utf-8 -*-
# Part of Odoo. See LICENSE file for full copyright and licensing details.
from werkzeug import urls

from odoo import api, fields, models, _
from odoo.http import request
from odoo.tools.json import scriptsafe as json_scriptsafe
from odoo.exceptions import UserError, ValidationError

class MrpBom(models.Model):
    _inherit = 'mrp.bom'

    category_category = fields.Selection(related='product_tmpl_id.categ_id.category_category', string='物料类型')

    this_attribute_configure_line_id = fields.Many2one('mrp.bom.attribute.configure.line', copy=False)
    this_garment_attribute_configure_line_id = fields.Many2one('mrp.bom.attribute.configure.line',copy=False)
    materiel_product_template_id = fields.Many2one('product.template',related='this_attribute_configure_line_id.product_template_id', string='产品')
    position_name = fields.Char(string='部位',related='this_attribute_configure_line_id.position_name', readonly=False, store=True)
    second_uom_id = fields.Many2one('uom.uom',related='materiel_product_template_id.second_uom_id', string='用量单位')
    materiel_uom_id = fields.Many2one('uom.uom',related='materiel_product_template_id.uom_po_id', string='采购单位')
    materiel_accessory_uom_rate = fields.Float(related='materiel_product_template_id.accessory_uom_rate', string='换算比例')
    garment_qty = fields.Integer(related='this_attribute_configure_line_id.garment_qty', string='成衣数量', readonly=False, store=True)
    materiel_qty = fields.Integer(related='this_attribute_configure_line_id.materiel_qty', string='物料数量', readonly=False, store=True)
    
    wastage = fields.Float(string='损耗%',related='this_attribute_configure_line_id.wastage',readonly=False, store=True)
    change_picture_bom_count = fields.Integer(compute="_compute_change_picture_bom_count")

	# 匹配尺码-快速填写当前物料对应成衣的尺码
    def action_match_size(self):
        for data in self:
            size_dict = {}
            match_line = data.this_attribute_configure_line_size_ids.filtered(lambda l: not l.is_readonly)
            size_attribute_line = data.product_tmpl_id.attribute_line_ids.filtered(
                lambda l: l.attribute_id.type == 'size')
            for index, value in enumerate(size_attribute_line.value_ids):
                size_dict.update({
                    f'value{30 + index}_id': value
                })
            match_attribute_size_line = match_line.product_template_id.attribute_line_ids.filtered(
                lambda l: l.attribute_id.type == 'size')
            match_size = match_attribute_size_line.value_ids
            for key, value in size_dict.items():
                if value in match_size:
                    attribute_value = match_attribute_size_line.product_template_value_ids.filtered(
                        lambda l: l.product_attribute_value_id == value)
                    match_line[key] = attribute_value

        return match_line.action_open_self_mo()

    def _compute_change_picture_bom_count(selfs):
        for self in selfs:
            if self.is_change_bom or not self.sale_id:
                self.change_picture_bom_count =0
            else:
                self.change_picture_bom_count = len(self.search([('change_category', '=', 'picture'),('sale_id','=',self.sale_id.id)]))


    def action_view_change_picture_bom(self):
        change_boms = self.search([('change_category', '=', 'picture'),('sale_id','=',self.sale_id.id)])
        if len(change_boms) == 1:
             action = {'res_model': 'mrp.bom',
                       'type': 'ir.actions.act_window',
                       'view_mode': 'form',
                       'res_id': change_boms.id,

                       }
        else:
            domain=[('id','in', change_boms.ids)]
            action = self.env.ref('mrp.mrp_bom_form_action').read()[0]
            action['domain'] = domain
        return action

    @api.onchange('garment_qty','materiel_qty')
    def onchange_materiel_qty(self):
        self.this_attribute_configure_line_qty_ids.default_qty = self.materiel_qty / ( self.garment_qty or 99999)
        self.this_attribute_configure_line_qty_ids[-1:].onchange_from_default_qty()
    
    
    attribute_configure_line_ids = fields.One2many('mrp.bom.attribute.configure.line', 'bom_id',copy=True)

    def _attribute_configure_line_color_domain(self):
        if self._context.get('garment_line') or self._context.get('this_line'):
            return  [('id','in',[self._context.get('garment_line'),self._context.get('this_line')])]
        else:
            return  []
    this_attribute_configure_line_color_ids = fields.One2many('mrp.bom.attribute.configure.line', 'bom_id',copy=False,domain=lambda s:s._attribute_configure_line_color_domain())


    def _attribute_configure_line_size_domain(self):
        if self._context.get('garment_line') or self._context.get('this_line'):
            return  [('id','in',[self._context.get('garment_line'),self._context.get('this_line')])]
        else:
            return  []
    this_attribute_configure_line_size_ids = fields.One2many('mrp.bom.attribute.configure.line', 'bom_id',copy=False,domain=lambda s:s._attribute_configure_line_size_domain())


    def _attribute_configure_line_qty_domain(self):
        if self._context.get('garment_line') or self._context.get('this_line'):
            return  [('id','in',[self._context.get('this_line'),])]
        else:
            return  []
    this_attribute_configure_line_qty_ids = fields.One2many('mrp.bom.attribute.configure.line', 'bom_id',copy=False,domain=lambda s:s._attribute_configure_line_qty_domain())







    sale_id = fields.Many2one('sale.order', '销售订单', copy=False)
    sale_product_ids = fields.Many2many('product.product', 'mrp_bom_sale_product_product_rel',
                                        'bom_id', 'product_id', string='销售变体', copy=False)
    last_bom_id = fields.Many2one('mrp.bom', '关联数据bom', copy=False)
    last_bom_name = fields.Char(string='上一单编号', copy=False)
    origin_order_name = fields.Char(string='原始单', copy=False)

    @api.depends('product_tmpl_id')
    def _compute_product_color_attribute_value_ids(selfs):
        for self in selfs:
            color_attribute_line = self.product_tmpl_id.attribute_line_ids.filtered(
                lambda l: l.attribute_id.type == 'color'
            )
            self.product_color_attribute_value_ids = color_attribute_line.product_template_value_ids
    product_color_attribute_value_ids = fields.Many2many('product.template.attribute.value',
                                                 'mrp_bom_product_template_color_value_rel', 'bom_id', 'color_value_id',
                                                 '颜色值',
                                                 compute='_compute_product_color_attribute_value_ids',store=True)



    
    @api.depends('product_tmpl_id')
    def _compute_product_id_size_attribute_value_ids(selfs):
        for self in selfs:
            size_attribute_line = self.product_tmpl_id.attribute_line_ids.filtered(
                lambda l: l.attribute_id.type == 'size'
            )
            self.product_size_attribute_value_ids = size_attribute_line.product_template_value_ids
    product_size_attribute_value_ids = fields.Many2many('product.template.attribute.value',
                                                 'mrp_bom_product_template_size_value_rel', 'bom_id', 'size_value_id',
                                                 '尺码值', compute='_compute_product_id_size_attribute_value_ids',store=True)

    
    @api.depends('color_attribute_value_ids')
    def _compute_color_attribute_values_count(selfs):
        for self in selfs:
            self.color_attribute_values_count = len(self.product_color_attribute_value_ids)
    color_attribute_values_count = fields.Integer(compute='_compute_color_attribute_values_count')

    @api.depends('size_attribute_value_ids')
    def _compute_size_attribute_values_count(selfs):
        for self in selfs:
            self.size_attribute_values_count = len(self.product_size_attribute_value_ids)
    size_attribute_values_count = fields.Integer(compute='_compute_size_attribute_values_count')


    @api.onchange('sale_id')
    def onchange_sale_id_for_code(self):
        self.code = self.sale_id.name

    @api.onchange('sale_id', 'product_tmpl_id')
    def onchange_from_sale_product_tmpl_id(self):
        self.sale_product_ids = self.sale_id.order_line.mapped('product_id').filtered(
            lambda p: p.product_tmpl_id in self.product_tmpl_id)
#修复无法创建BOM
    @api.depends('sale_product_ids',)
    def _compute_color_attribute_value_ids(selfs):
        for self in selfs:
            self.color_attribute_value_ids = self.sale_product_ids.mapped(
                'product_template_variant_value_ids').filtered(lambda v: v.type == 'color').sorted('sequence') 
    color_attribute_value_ids = fields.Many2many('product.template.attribute.value',
                                                 'mrp_bom_product_template_color_value_rel', 'bom_id', 'color_value_id',
                                                 '颜色值',
                                                 compute='_compute_color_attribute_value_ids',)

    @api.depends('color_attribute_value_ids')
    def _compute_sale_color_attribute_value_sequences(selfs):
        for self in selfs:
            self.sale_color_attribute_value_sequences = ''.join([
                '|', '|'.join(sorted([str(each) for each in self.color_attribute_value_ids.mapped('sequence')])), '|'
            ])
    sale_color_attribute_value_sequences = fields.Char(compute='_compute_sale_color_attribute_value_sequences')


    @api.depends('sale_product_ids')
    def _compute_size_attribute_value_ids(selfs):
        for self in selfs:
            self.size_attribute_value_ids = self.sale_product_ids.mapped(
                'product_template_variant_value_ids').filtered(lambda v: v.type == 'size').sorted('sequence')
    size_attribute_value_ids = fields.Many2many('product.template.attribute.value',
                                                 'mrp_bom_product_template_size_value_rel', 'bom_id', 'size_value_id',
                                                 '尺码值', compute='_compute_size_attribute_value_ids',)

    @api.depends('size_attribute_value_ids')
    def _compute_sale_size_attribute_value_sequences(selfs):
        for self in selfs:
            self.sale_size_attribute_value_sequences = ''.join([
                '|', '|'.join(sorted([str(each) for each in self.size_attribute_value_ids.mapped('sequence')])), '|'
            ])
    sale_size_attribute_value_sequences = fields.Char(compute='_compute_sale_size_attribute_value_sequences')


    @api.onchange('product_tmpl_id')
    def onchange_for_default_attribute_configure_line(self):
        if self.category_category =='good':
            self.update({
            'attribute_configure_line_ids': [(5,)],
        })
            self.update_default_attribute_configure_line()


    def update_default_attribute_configure_line_per_page(self):
        self = self.sudo()
        sequence = 11
        self.attribute_configure_line_ids.filtered(lambda l: l.is_readonly)[1:].unlink()
        for line in self.attribute_configure_line_ids.filtered(lambda l: not l.is_readonly and l.product_template_id).sorted(
                key=lambda r: (r.position_id.sequence, r.product_category_id.serial_number , r.product_template_id.id)
            ):
#            if sequence % 11 == 10:
#                common_values = {
#                    'product_template_id': self.product_tmpl_id.id,
#                    'is_readonly': True,
#                    'sequence':sequence,
#                }
#
#                color_attribute_values = self.product_tmpl_id.attribute_line_ids.filtered(
#                    lambda l: l.attribute_id.type == 'color'
#                    ).product_template_value_ids
#                color_values = {
#                    f'value{10+i}_id': template_value.id
#                    for i, template_value in enumerate(color_attribute_values)
#                }
#                size_attribute_values = self.product_tmpl_id.attribute_line_ids.filtered(
#                    lambda l: l.attribute_id.type == 'size'
#                ).product_template_value_ids
#                size_values = {
#                     f'value{30+i}_id': template_value.id
#                     for i, template_value in enumerate(size_attribute_values)
#                }
#                if not all([
#                    color_values,
#                    size_values
#                ]):
#                    return True
#                self.write({
#                    'attribute_configure_line_ids': [(0,0,dict(common_values,**color_values,**size_values))]
#                })
#                sequence += 1
            line.write({'sequence':sequence})
            sequence += 1

    def update_default_attribute_configure_line(self):
        common_values = {
            'product_template_id': self.product_tmpl_id.id,
            'is_readonly': True,
            'sequence':10,
        }

        color_attribute_values = self.product_tmpl_id.attribute_line_ids.filtered(
            lambda l: l.attribute_id.type == 'color'
        ).product_template_value_ids.filtered(
            lambda l: l.ptav_active
        ).sorted('sequence')
#        raise UserError(str(color_attribute_values))
        color_values = {
            f'value{10+i}_id': template_value.id
            for i, template_value in enumerate(color_attribute_values)
        }

        size_attribute_values = self.product_tmpl_id.attribute_line_ids.filtered(
            lambda l: l.attribute_id.type == 'size'
        ).product_template_value_ids.filtered(
            lambda l: l.ptav_active
        ).sorted('sequence')
        size_values = {
            f'value{30+i}_id': template_value.id
            for i, template_value in enumerate(size_attribute_values)
        }
        if not all([
            color_values,
            size_values
        ]):
            return True

        self.attribute_configure_line_ids.filtered(lambda l: l.is_readonly).unlink()
        self.write({
            'attribute_configure_line_ids': [(0,0,dict(common_values,**color_values,**size_values))]
        })
        if self.last_bom_id:
            last_bom = self.last_bom_id
        else:
            last_bom = self.sudo().search([
                ('product_tmpl_id', '=', self.product_tmpl_id.id),
                ('id', '!=', self._origin.id),('is_change_bom','=',False),('is_qty_change_bom','=',False)
            ],order='create_date desc', limit=1)
#        raise UserError(last_bom[0])
#        orders = self.env['sale.order.line'].sudo().search([('product_template_id','=',self.product_tmpl_id.id),('state','=','sale')]).mapped('order_id').sorted(
#                key=lambda r: r.id
#            )
#        if orders:
#            for order in orders:
#                last_bom |= self.env['mrp.bom'].sudo().search([
#('product_tmpl_id', '=',self.product_tmpl_id.id),
#('sale_id', '=',order.id),('is_change_bom','=',False)
#], limit=1)
#                if last_bom:
#                    break
#            
##        raise UserError([last_bom,orders])
        if last_bom:
#            raise UserError(last_bom)
            self.update({
                'last_bom_id':last_bom[0].id,
                'last_bom_name':last_bom[0].display_name,
                'operation_ids': [
                    (0,0,operation_id.copy_data()[0])
                    for operation_id in last_bom[0].operation_ids
                ],
                'attribute_configure_line_ids': [
                    (0,0,attribute_configure_line.copy_data()[0])
                    for attribute_configure_line in last_bom[0].attribute_configure_line_ids.filtered(lambda l: l.need_copy)[1:]
                ]
            })
            operations_mapping = {}

            for original, copied in zip(last_bom[0].operation_ids, self.operation_ids.sorted()):
                operations_mapping[original] = copied
            for bom_line in self.attribute_configure_line_ids:
                if bom_line.operation_id and operations_mapping.get(bom_line.operation_id):
                    bom_line.operation_id = operations_mapping[bom_line.operation_id]


  

    def action_configure_bom_lines(self):
        origin_bom_line = self.bom_line_ids
        this_attribute_configure_lines = self.attribute_configure_line_ids[1:].filtered(lambda l: l.is_choose)
        bom_line_values_list = [(2,bom_line.id) for bom_line
                                in self.bom_line_ids.filtered(lambda bl: bl.configure_line_id in this_attribute_configure_lines)]
#        raise UserError([this_attribute_configure_lines,this_attribute_configure_lines.product_template_id.name])
#        raise UserError([self.color_attribute_value_ids,self.size_attribute_value_ids])
        for i, color_template_value in enumerate(self.color_attribute_value_ids):
            for j, size_template_value in enumerate(self.size_attribute_value_ids):
                for configure_line in this_attribute_configure_lines:
                    component_color_template_value = configure_line[f'value{color_template_value.sequence}_id']
                    component_size_template_value = configure_line[f'value{size_template_value.sequence}_id']
                    # component_color_template_value = configure_line[f'value{10 + i}_id']
                    # component_size_template_value = configure_line[f'value{30 + j}_id']
                    component_variant = configure_line.product_template_id.product_variant_ids.filtered(
                        lambda pv: pv.product_template_attribute_value_ids == component_color_template_value+component_size_template_value
                    )
#                    raise UserError([component_variant, configure_line.product_template_id.product_variant_ids,j,size_template_value,size_template_value.sequence])
                    if not component_variant:
#                        raise UserError([component_color_template_value,component_size_template_value])
                        continue
#                    raise UserError(color_template_value._name)
                    # 处理-物料精度
                    rounding = str(int(1/ self.product_uom_id.rounding))
                    this_rounding = len(rounding) - 1
                    qty = round(configure_line[f'real_qty{size_template_value.sequence-30}'] * ( 1 + configure_line.wastage / 100),this_rounding)
                    bom_line_values_list.append((0,0,{
                        'configure_line_id':configure_line.id,
                        'position_name':configure_line.position_name,
                        'position_id':configure_line.position_id.id,
                        'operation_id':configure_line.operation_id.id,
                        'product_id': component_variant.id,
                        'product_qty': qty,
                        'bom_product_template_attribute_value_ids': [(6, 0, [color_template_value.id, size_template_value.id])]
                    }))
                    
                    configure_line.has_create_bom_line = True
        if this_attribute_configure_lines.filtered(lambda l: not l.has_create_bom_line):
            raise UserError('无法确认，"%s"未能产生任何BOM行'  % this_attribute_configure_lines.filtered(lambda l: not l.has_create_bom_line)[0].product_template_id.name)
        self.write({'bom_line_ids':bom_line_values_list})


    def multi_action_bom_configure_line_confirmed(selfs):
        for self in selfs:
            lines = self.attribute_configure_line_ids.filtered(lambda l: l.is_choose == True)
            if lines.filtered(lambda l: l.qty_confirmed):
                raise ValidationError("技术:所选择的物料已存在技术确认,不能重复技术确认!")
            lines.multi_action_bom_line_confirmed()
            lines.write({'is_choose':False})

    # BOM全选按钮-快速选择
    def all_action_bom_configure_line_confirmed(self):
        # 获取当前用户权限
        groups = self.env.user.groups_id
        if self.env.ref('res_groups.Technical_department_group') in groups:
            # 自动选择 业务确认但技术未确认的物料
            lines = self.attribute_configure_line_ids.filtered(lambda l: l.confirmed and not l.qty_confirmed)
            lines.is_choose = True
        else:
            # 自动选择 业务确认未确认和技术未确认的物料
            lines = self.attribute_configure_line_ids.filtered( lambda l: not l.confirmed and not l.is_readonly)
            lines.is_choose = True

    # 技术确认
    def action_configure_qty_confirmed(selfs):
        for self in selfs:
            self = self.sudo()
            lines = self.attribute_configure_line_ids.filtered(lambda l: l.is_choose == True and not l.qty_confirmed)
            lines = lines.sudo()
            if lines.filtered(lambda l: not l.confirmed):
                raise UserError('技术:无法确认，"%s"业务未确认' %lines.filtered(lambda l: not l.confirmed)[0].product_template_id.name)
            if lines.filtered(lambda l: not l.operation_id):
                raise UserError('技术:物料的消耗在作业(工序)没有填写,需填写后再确认')
            lines.check_attributes()
            lines.check_qty()
            self.action_configure_bom_lines()
            lines.action_qty_confirmed()
            lines.write({'is_choose': False})


    def copy(self, default=None):
        res = super().copy(default)
        res.other_1_image_1920 = self.other_1_image_1920
        res.other_2_image_1920 = self.other_2_image_1920
        res.other_3_image_1920 = self.other_3_image_1920
        res.other_4_image_1920 = self.other_4_image_1920
        res.other_5_image_1920 = self.other_5_image_1920
        res.other_6_image_1920 = self.other_6_image_1920
        res.other_7_image_1920 = self.other_7_image_1920
        res.other_8_image_1920 = self.other_8_image_1920
        res.other_9_image_1920 = self.other_9_image_1920
        res.other_10_image_1920 = self.other_10_image_1920
        res.other_11_image_1920 = self.other_11_image_1920
        res.other_12_image_1920 = self.other_12_image_1920
        res.other_13_image_1920 = self.other_13_image_1920
        res.other_14_image_1920 = self.other_14_image_1920
        
        if self.operation_ids:
            operations_mapping = {}
            for original, copied in zip(self.operation_ids, res.operation_ids.sorted()):
                operations_mapping[original] = copied
            for bom_line in res.attribute_configure_line_ids:
                if bom_line.operation_id:
                    bom_line.operation_id = operations_mapping[bom_line.operation_id]
        return res

    is_change_bom = fields.Boolean(copy=False,default=False)
    change_category= fields.Selection(
        [('material', '技术变更'), ('quantity', '用量变更'), ('pmc', '替代料'), ('picture', '图片变更')],
        tracking=15,
        string='变更类型',
        copy=False,
    )
    is_qty_change_bom = fields.Boolean(copy=False,default=False)
    is_sku_qty_change_bom = fields.Boolean(copy=False,default=False)
    change_bom_sequence = fields.Integer('变更单流水',default=0,copy=False)
    qty_change_bom_sequence = fields.Integer('变更单流水',default=0,copy=False)
    pmc_change_bom_sequence = fields.Integer('替代料流水',default=0,copy=False)
    picture_change_bom_sequence = fields.Integer('图片变更流水',default=0,copy=False)
    change_state= fields.Selection([('approve', '通过'), ('reject', '拒绝')],tracking=15,string='变更状态', copy=False,)
    origin_bom_id = fields.Many2one('mrp.bom', string='原BOM')

    # 检查BOM变更-行数据,超行数,技术未确认,空选择
    def check_lines(self):
        choose_lines = self.attribute_configure_line_ids.filtered(lambda l: l.is_choose)
        not_need_change = choose_lines.filtered(lambda l: not l.qty_confirmed)
        if  choose_lines and len(choose_lines) > 5:
            raise UserError('考虑变更UI界面，一次变更不超过5个物料')
        elif  not_need_change:
            raise UserError('请不要选择技术还未确认的物料,技术未确认的物料可以直接修改无需变更')
        elif not choose_lines:
            raise UserError('请先选择要变更的物料')
    
    #检查替代料面料不能和辅料、包材混合申请
    def check_product_category(self):
        if (set(list(self.attribute_configure_line_ids[1:].filtered(lambda l: l.is_choose).mapped('product_category_id').ids)) & set([6, 42, 44, 54, 56, 31, 71, 406, 64, 59, 81, 130, 407, 65, 408, 76, 4, 75, 78, 77, 7, 66, 79, 80, 109])) and (set(list(self.attribute_configure_line_ids[1:].filtered(lambda l: l.is_choose).mapped('product_category_id').ids)) &
        set([12, 425, 403, 411, 37, 412, 28, 29, 419, 421, 427, 426, 366, 13, 5, 372, 371, 428, 418, 417, 16, 120, 424, 420, 49, 8, 57, 106, 67, 17, 423, 68, 74, 126, 20, 19, 121, 124, 122, 405, 398, 51])):
            raise UserError('面料不能和辅料、包材合并提交替换料申请')

    # 检查当前BOM是否存在‘草稿’或‘审批中’的变更单
    def check_other_change_bom(self):
        other_bom = self.search([('origin_bom_id','=',self.id),('state','in',('draft','to_approve')),('change_state','=',False)])
        if other_bom :
            raise UserError('你好,该订单存在【草稿、审批中】的变更BOM,请先完成进行中的BOM再做变更申请')




    # 检查用量变更行数据
    def check_qty_lines(self):
        choose_lines = self.attribute_configure_line_ids.filtered(lambda l: l.is_choose)
        not_need_change = choose_lines.filtered(lambda l: not l.qty_confirmed)
        if  not_need_change:
            raise UserError('请不要选择技术还未确认的物料')
        elif not choose_lines:
            raise UserError('请选择要变更的物料')



    def action_supplied_by_subsupplier(self):
        self = self.sudo()
        confirmed_lines = self.attribute_configure_line_ids.filtered(lambda l: l.is_choose == True and l.qty_confirmed)
        confirmed_lines.bom_line_id.product_qty = 0
        confirmed_lines.supplied_by_subsupplier = True
        unconfirmed_lines = self.attribute_configure_line_ids.filtered(lambda l: l.is_choose == True and not l.qty_confirmed)
        unconfirmed_lines.qty_confirmed = True
        unconfirmed_lines.bom_line_id.product_qty = 0
        unconfirmed_lines.qty_confirmed_date = fields.Datetime.now()
        unconfirmed_lines.supplied_by_subsupplier = True
        unconfirmed_lines.is_choose = False
        products = confirmed_lines.bom_line_id.product_id | unconfirmed_lines.bom_line_id.product_id


    # 工序图片 + 工序备注
    other_1_image_1920 = fields.Image("Variant Image", max_width=1920, max_height=1920,copy=True)
    other_2_image_1920 = fields.Image("Variant Image", max_width=1920, max_height=1920,copy=True)
    other_3_image_1920 = fields.Image("Variant Image", max_width=1920, max_height=1920,copy=True)
    other_4_image_1920 = fields.Image("Variant Image", max_width=1920, max_height=1920,copy=True)
    other_5_image_1920 = fields.Image("Variant Image", max_width=1920, max_height=1920,copy=True)
    other_6_image_1920 = fields.Image("Variant Image", max_width=1920, max_height=1920,copy=True)
    other_7_image_1920 = fields.Image("Variant Image", max_width=1920, max_height=1920,copy=True)
    other_8_image_1920 = fields.Image("Variant Image", max_width=1920, max_height=1920,copy=True)
    other_9_image_1920 = fields.Image("Variant Image", max_width=1920, max_height=1920,copy=True)
    other_10_image_1920 = fields.Image("Variant Image", max_width=1920, max_height=1920,copy=True)
    other_11_image_1920 = fields.Image("Variant Image", max_width=1920, max_height=1920,copy=True)
    other_12_image_1920 = fields.Image("Variant Image", max_width=1920, max_height=1920,copy=True)
    other_13_image_1920 = fields.Image("Variant Image", max_width=1920, max_height=1920,copy=True)
    other_14_image_1920 = fields.Image("Variant Image", max_width=1920, max_height=1920,copy=True)
    other_15_image_1920 = fields.Image("Variant Image", max_width=1920, max_height=1920,copy=True)
    other_1_image_remark = fields.Text('备注')
    other_2_image_remark = fields.Text('备注')
    other_3_image_remark = fields.Text('备注')
    other_4_image_remark = fields.Text('备注')
    other_5_image_remark = fields.Text('备注')
    other_6_image_remark = fields.Text('备注')
    other_7_image_remark = fields.Text('备注')
    other_8_image_remark = fields.Text('备注')
    other_9_image_remark = fields.Text('备注')
    other_10_image_remark = fields.Text('备注')
    other_11_image_remark = fields.Text('备注')
    other_12_image_remark = fields.Text('备注')
    other_13_image_remark = fields.Text('备注')
    other_14_image_remark = fields.Text('备注')
    other_15_image_remark = fields.Text('备注')

    # 设置 翻单不复制
    def set_not_copy_next_bom(self):
        choose_lines = self.attribute_configure_line_ids.filtered(lambda l: l.is_choose)
        choose_lines.need_copy = False
        choose_lines.is_choose = False
        
    def set_need_copy_next_bom(self):
        choose_lines = self.attribute_configure_line_ids.filtered(lambda l: l.is_choose)
        choose_lines.need_copy = True
        choose_lines.is_choose = False

    def copy_similar_mrp_bom(self):
        self.ensure_one()
        context = dict(self._context)
        context.update({'default_bom_id': self.id})
        return {
            'name': _('复制相似的BOM'),
            'type': 'ir.actions.act_window',
            'view_mode': 'form',
            'res_model': 'mrp.bom.copy.wizard',
            'view_id': self.env.ref('bom_attribute_configure.view_mrp_bom_copy_wizard_wizard').id,
            'context': context,
            "target": "new"
        }

    def action_change_operation(self):
        pass