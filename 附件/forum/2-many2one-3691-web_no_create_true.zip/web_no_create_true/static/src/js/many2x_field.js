/** @odoo-module **/

import { Many2OneField } from '@web/views/fields/many2one/many2one_field';
import { Many2ManyTagsField } from '@web/views/fields/many2many_tags/many2many_tags_field';

const { markup } = owl;

/*  no_create, no_create_edit默认值设置为True
*/
const extractProps = Many2OneField.extractProps;
Many2OneField.extractProps = ({ attrs, field }) => {
	if(attrs.options.no_create === undefined){
		attrs.options.no_create = true;
	}
	if(attrs.options.no_create_edit === undefined){
		attrs.options.no_create_edit = true;
	}
	var props = extractProps({ attrs, field });
	return props;
};

//const extractProps2 = Many2ManyTagsField.extractProps;
//Many2ManyTagsField.extractProps = ({ attrs, field }) => {
//	if(attrs.options.no_create === undefined){
//		attrs.options.no_create = true;
//	}
//	if(attrs.options.no_create_edit === undefined){
//		attrs.options.no_create_edit = true;
//	}
//	var props = extractProps2({ attrs, field });
//	return props;
//};
