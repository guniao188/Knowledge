# -*- coding: utf-8 -*-

{
    'name': 'Many2one, Many2many Options的设置项no_create, no_create_edit默认值设置为True',
    'version': '16.01',
    'category': 'Hidden',
    'summary': 'Many2one, Many2many Options的设置项no_create, no_create_edit默认值设置为True',
    'description': """
    1) Many2one, Many2many Options的设置项no_create, no_create_edit默认值设置为False，本模块将此默认值修改为True
""",
    'depends': ['web', ],
    'data': [
    ],
    'demo': [ ],
    'assets': {
        'web.assets_backend': [
            'web_no_create_true/static/src/js/many2x_field.js',
        ],
    },
    'installable': True,
    'auto_install': False,
}
