# See LICENSE file for full copyright and licensing details.

{
    'name': '销售、财务单据上增加事业部字段',
    'version': '0.5',
    'category': 'Sales',
    'license': 'AGPL-3',
    'author': 'OSCG',
    'website': 'http://www.oscg.cn',
    'maintainer': 'OSCG',
    'summary': '销售、财务单据上增加事业部字段',
    'description': """
        1)  一班人马多个公司，业务本质上是一个公司，但因为避税等原因，注册了多个公司
        2)  销售单据、财务单据上增加事业部字段，用以区分不同公司的单据
        """,
    'depends': [
        'sale',
    ],
    'data': [
        'views/account_view.xml',
        'views/sale_view.xml',
        'security/ir.model.access.csv',
    ],
    'installable': True,
    'auto_install': False,
}
