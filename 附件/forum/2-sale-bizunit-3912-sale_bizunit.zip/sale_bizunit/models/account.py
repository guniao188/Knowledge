# See LICENSE file for full copyright and licensing details.

from odoo import api, models, fields
from odoo.exceptions import UserError


class ResBizunit(models.Model):
    _name = "res.bizunit"
    _description = "事业部"
    
    name = fields.Char('名称')
    code = fields.Char('代码')
    position_id = fields.Many2one('account.fiscal.position', '财税替换')
    active = fields.Boolean(default=True)
    company_id = fields.Many2one('res.company', '公司', required=True, default=lambda self: self.env.company)

class AccountMove(models.Model):
    _inherit = "account.move"

    bizunit_id = fields.Many2one('res.bizunit', '事业部')


class AccountMoveLine(models.Model):
    _inherit = "account.move.line"

    bizunit_id = fields.Many2one('res.bizunit', related='move_id.bizunit_id', store=True)
    