# See LICENSE file for full copyright and licensing details.

from odoo import api, models, fields, api
from odoo.exceptions import UserError


class SaleOrder(models.Model):
    _inherit = "sale.order"

    bizunit_id = fields.Many2one('res.bizunit', '事业部')

    @api.onchange("bizunit_id")
    def _onchange_bizunit_id(self):
        if self.bizunit_id:
            self.fiscal_position_id = self.bizunit_id.position_id
            

class SaleOrderLine(models.Model):
    _inherit = "sale.order.line"

    bizunit_id = fields.Many2one('res.bizunit', related='order_id.bizunit_id', store=True)


class SaleAdvancePaymentInv(models.TransientModel):
    _inherit = "sale.advance.payment.inv"
    
    def _prepare_invoice_values(self, order, name, amount, so_line):
        invoice_vals = super()._prepare_invoice_values(order, name, amount, so_line)
        invoice_vals.update({
            'bizunit_id': order.bizunit_id.id,
        })