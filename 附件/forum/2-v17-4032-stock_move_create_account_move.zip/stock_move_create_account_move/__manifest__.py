# -*- coding: utf-8 -*-
{
    'name': "根据出入库对账",

    'description': """
     采购/订单 | 销售/订单 下面增加菜单“对账”，该菜单显示状态为['done'] 的 stock_move
     基于入库/输出数据，导出数据到Excel 作成对账单
     基于对账数量创建账单
    """,
    'author': "OSCG",
    'website': 'http://www.oscg.cn',
    'category': 'Purchase',
    'version': '0.1',
    'depends': ['purchase_stock','account','purchase','sale'],
    'data': [
        "views/stock_move.xml",
        "views/purchase_order.xml",
        "views/res_partner.xml",
         "data/server_actions.xml"
    ],
}