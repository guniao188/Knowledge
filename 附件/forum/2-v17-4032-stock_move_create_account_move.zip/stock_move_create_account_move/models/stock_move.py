# -*- coding: utf-8 -*-
from odoo import api, fields, models, _
from odoo.exceptions import AccessError, UserError, ValidationError

        

class StockMove(models.Model):
    _inherit = "stock.move"

    purchase_partner_ref = fields.Char(related='purchase_line_id.order_id.partner_ref', store=True, string='供应商订单号')
    sale_partner_ref = fields.Char(related='sale_line_id.order_id.client_order_ref', store=True, string='客户订单号')
    qty_to_fapiao = fields.Float(string='对账数', digits='Product Unit of Measure')
    invoice_lines = fields.One2many('account.move.line', 'stock_move_id', string="Bill Lines", readonly=True, copy=False)
    purchase_price_unit = fields.Float(string='单价',related='purchase_line_id.price_unit',store=True)
    sale_price_unit = fields.Float(string='单价',related='sale_line_id.price_unit',store=True)


    @api.depends('purchase_line_id', 'sale_line_id')
    def _compute_bill_partner_id(selfs):
        for line in selfs:
            line.purchase_partner_id = line.purchase_line_id.order_id.partner_id
            line.sale_partner_id = line.sale_line_id.order_id.partner_id
            line.monthly_balance = line.purchase_line_id.order_id.partner_id.monthly_balance or line.sale_line_id.order_id.partner_id.monthly_balance
    purchase_partner_id = fields.Many2one('res.partner', string="供应商", store=True,compute='_compute_bill_partner_id', )    
    sale_partner_id = fields.Many2one('res.partner', string="客户", store=True,compute='_compute_bill_partner_id', )

    monthly_balance = fields.Boolean("月结",compute='_compute_bill_partner_id',store=True)
 
    @api.depends('invoice_lines.move_id.state', 'invoice_lines.quantity', 'quantity',  'state')
    def _compute_qty_invoiced(selfs):
        for line in selfs:
            qty = 0.0
            for inv_line in line.invoice_lines:
                if inv_line.move_id.state not in ['cancel'] or inv_line.move_id.payment_state == 'invoicing_legacy':
                    if inv_line.move_id.move_type in ('in_invoice','out_invoice'):
                        qty += inv_line.product_uom_id._compute_quantity(inv_line.quantity, line.product_uom)
                    elif inv_line.move_id.move_type in ('in_refund','out_refund'):
                        qty -= inv_line.product_uom_id._compute_quantity(inv_line.quantity, line.product_uom)
            line.qty_invoiced = qty

            if line.state in ['done']:
                real_qty_invoiced = line.qty_invoiced if (line.location_id.usage =="supplier" or line.location_dest_id.usage =="customer") else -line.qty_invoiced
                line.qty_to_invoice = line.quantity - real_qty_invoiced
            else:
                line.qty_to_invoice = 0
    qty_invoiced = fields.Float(compute='_compute_qty_invoiced', string="已对账数", digits='Product Unit of Measure', store=True)

    qty_to_invoice = fields.Float(compute='_compute_qty_invoiced', string='待对账数', store=True, readonly=True,
                                  digits='Product Unit of Measure')


    @api.constrains('qty_to_fapiao')
    def check_qty_to_fapiao(selfs):
        for self in selfs:
            real_qty_invoiced = self.qty_invoiced if (self.location_id.usage =="supplier" or self.location_dest_id.usage =="customer") else -self.qty_invoiced
            if self.qty_to_fapiao + real_qty_invoiced > self.quantity:
                raise UserError('此次对账数不能大于入库数-已对账数')
            if self.qty_to_fapiao < 0:
                raise UserError('此次对账数应该是正数')

    def make_bill(selfs):
        is_purchase_bill = selfs.mapped('purchase_line_id')
        is_customer_invoice = selfs.mapped('sale_line_id')
        if (not is_purchase_bill) and (not is_customer_invoice):
            raise UserError('请选择入库、出库单据对账')
        if is_purchase_bill and is_customer_invoice:
            raise UserError('入库、出库单请分开对账')
        invoice_partner = selfs.mapped('purchase_line_id.order_id.partner_id.name') or selfs.mapped('sale_line_id.order_id.partner_id.name')
        if len(set(invoice_partner)) > 1:
            raise UserError("不同供应商、客户不可以合并创建账单！-- %s" % set(invoice_partner) )
        
        invoice_item_sequence = 0
        invoice_vals = None
        origins = set()
        payment_refs = set()
        refs = set()
        for line in selfs:
            if line.state != 'done':
                continue
            if line.qty_to_fapiao <= 0:
                continue
            if not invoice_vals:
                order = line.purchase_line_id.order_id or line.sale_line_id.order_id
                
                invoice_vals = order.with_company(line.company_id)._prepare_invoice()
            invoice_item_sequence += 1
            invoice_line = line._prepare_account_move_line()
            invoice_line.update({'sequence': invoice_item_sequence})
 
            invoice_vals['invoice_line_ids'].append((0, 0, invoice_line))
#            invoice_vals['invoice_line_ids'].append(invoice_line)
            
            origins.add(line.purchase_line_id.order_id.name or line.sale_line_id.order_id.name)
            ref =  line.purchase_partner_ref or line.sale_partner_ref
            if ref:
                refs.add(ref)
            line.qty_to_fapiao = 0
  
        invoice_vals.update({
            'ref': ', '.join(refs)[:2000],
            'invoice_origin': ', '.join(origins),
            'payment_reference': ', '.join(refs)[:2000],
        })
        if line.purchase_line_id:
            move = selfs.env['account.move'].sudo().with_context(default_move_type='in_invoice').create(invoice_vals)
        else:
            move = selfs.env['account.move'].sudo().with_context(default_move_type='out_invoice').create(invoice_vals)
        if move.amount_total <0:
            move.action_switch_move_type()
        return move.id

    def view_invoice(selfs, invoice_ids):
        is_purchase_bill = selfs.mapped('purchase_line_id')
        if is_purchase_bill:
            action = selfs.env.ref('account.action_move_in_invoice_type').read()[0]
        else:
            action = selfs.env.ref('account.action_move_out_invoice_type').read()[0]
        if len(invoice_ids) > 1:
            action['domain'] = [('id', 'in', invoice_ids)]
        elif len(invoice_ids) == 1:
            action['views'] = [(selfs.env.ref('account.view_move_form').id, 'form')]
            action['res_id'] = invoice_ids[0]
        return action


  
    def _prepare_account_move_line(self):
        self.ensure_one()
        aml_currency = self.purchase_line_id.currency_id or self.sale_line_id.order_id.pricelist_id.currency_id
        date = fields.Date.today()
        res = {
            'display_type': 'product',
            'name': '%s: %s' % (self.purchase_line_id.order_id.name or self.sale_line_id.order_id.name, self.name or self.product_id.name),
            'product_id': self.product_id.id,
            'product_uom_id': self.product_uom.id,
            'quantity': self.qty_to_fapiao if (self.location_id.usage =="supplier" or self.location_dest_id.usage =="customer") else -self.qty_to_fapiao,
             'discount': self.purchase_line_id.discount or self.sale_line_id.discount or 0.00,
            'price_unit': aml_currency._convert(self.purchase_line_id.price_unit or self.sale_line_id.price_unit, aml_currency, self.company_id, date, round=False),
            'tax_ids': [(6, 0, self.purchase_line_id.taxes_id.ids or self.sale_line_id.tax_id.ids)],
            'purchase_line_id': self.purchase_line_id.id,
            'sale_line_ids': self.sale_line_id and [(6, 0, (self.sale_line_id.id,))],
            'stock_move_id':self.id,
        }
        if self.purchase_line_id.analytic_distribution:
            res['analytic_distribution'] = self.purchase_line_id.analytic_distribution
        if self.sale_line_id.analytic_distribution:
            res['analytic_distribution'] = self.sale_line_id.analytic_distribution
        return res

