# -*- coding: utf-8 -*-
from odoo import api, fields, models, _
from odoo.exceptions import AccessError, UserError, ValidationError

        

class PurchaseOrder(models.Model):
    _inherit = "purchase.order"



    @api.depends('partner_id')
    def _compute_monthly_balance(selfs):
        for self in selfs:
            self.monthly_balance = self.partner_id.monthly_balance
    monthly_balance = fields.Boolean("月结",compute='_compute_monthly_balance',store=True)


    def action_create_invoice(selfs):
        if selfs.mapped('partner_id').filtered(lambda p: p.monthly_balance):
            raise UserError('月结对账的供应商请在月结对账菜单创建账单')        
        return super().action_create_invoice()

