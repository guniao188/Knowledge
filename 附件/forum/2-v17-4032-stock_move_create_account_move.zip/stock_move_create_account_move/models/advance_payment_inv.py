# -*- coding: utf-8 -*-
from odoo import api, fields, models, _
from odoo.exceptions import AccessError, UserError, ValidationError

        

class SaleAdvancePaymentInv(models.TransientModel):
    _inherit = "sale.advance.payment.inv"

    def create_invoices(self):
        if self.advance_payment_method =='delivered' and self.sale_order_ids.mapped('partner_id').filtered(lambda p: p.monthly_balance):
            raise UserError('月结对账的客户请在月结对账菜单创建账单')        
        return super().create_invoices()
