# -*- coding: utf-8 -*-

from . import stock_move
from . import account_move_line
from . import res_partner
from . import purchase_order
from . import advance_payment_inv