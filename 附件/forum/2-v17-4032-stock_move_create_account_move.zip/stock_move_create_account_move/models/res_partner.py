# -*- coding: utf-8 -*-
from odoo import api, fields, models, _
from odoo.exceptions import AccessError, UserError, ValidationError

        

class ResPartner(models.Model):
    _inherit = "res.partner"

    monthly_balance  = fields.Boolean("月结", default=True)
