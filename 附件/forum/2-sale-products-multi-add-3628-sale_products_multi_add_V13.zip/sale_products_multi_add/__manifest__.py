# -*- coding: utf-8 -*-
{
    "name": "销售订单多选产品批量添加",
    "version": "13.0.1.0.0",
    "summary": "销售订单明细行的产品搜索更多时候，可以多选批量添加",
    "author": "OSCG",
    "website": "http://www.oscg.cn",
    "license": "AGPL-3",
    "category": "Sales/Sales",
    "depends": ["sale"],
    'data': [
        'views/assets.xml',
    ],

    "installable": True,
}
