odoo.define('sale_products_multi_add.up_down_ListRenderer', function (require) {
"use strict";
var ListRenderer = require('web.ListRenderer');

ListRenderer.include({
    _onNavigationMove: function (ev) {
    	this._super.apply(this, arguments);
        if(ev.data.direction === 'down'){
        	var currentFieldIndex = this.currentFieldIndex;
        	var rowIndex = this.currentRow + 1;
        	this._selectCell(rowIndex, currentFieldIndex, {force: true, wrap: true});
        	return;
        }
        if(ev.data.direction === 'up'){
        	var currentFieldIndex = this.currentFieldIndex;
        	var rowIndex = this.currentRow - 1;
        	this._selectCell(rowIndex, currentFieldIndex, {force: true, wrap: true});
        	return;
        }
    },
});

});

