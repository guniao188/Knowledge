# -*- coding: utf-8 -*-
# Part of Odoo. See LICENSE file for full copyright and licensing details.

{
    'name': 'to desk two',
    'version': '1.1',
    'category': 'Uncategorized',
    'summary': '桌面模块to desk2',
    'website': 'https://www.odoo.com/app/employees',
    'depends': [
        'base_setup',
        'mail',
        'resource',
        'web',
        'crm'
    ],
    'data': [
        'security/ir.model.access.csv',
        'views/customer.xml',
        'views/order.xml',
        'views/menu.xml',
        'views/calendar.xml',
    ],
    'demo': [

    ],
    'assets': {
        'web.assets_backend': [
            'todesk2/static/src/*/*.xml',
            'todesk2/static/src/*.xml',
            'todesk2/static/src/*/*.js',
        ],
    },
}
