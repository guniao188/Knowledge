from odoo import http

from odoo.http import request
import requests
import PyPDF2
# import pdfplumber
import json
from odoo.modules.module import get_resource_path


class Home(http.Controller):

    # 第一组信息
    @http.route('/web/todesk2/todeskcontrller4', type='json', auth="user", methods=['POST'])
    def todeskcontrller4(self, **kwargs):
        result = {
            "code": "200",
            "n0": [
                {
                    "id": "1",
                    "name": "线索丢失",
                    "date": "2023-12-12 12:20:20"
                },
                {
                    "id": "2",
                    "name": "线索丢失1",
                    "date": "2023-12-12 12:20:20"
                },
                {
                    "id": "3",
                    "name": "SoSo",
                    "date": "2023-12-12 12:20:20"
                }
            ],
            "n1": {
                "name": "消息",
                "number": "6",
                "type": "1"
            },
            "n2": {
                "name": "待处理",
                "number": "6",
                "type": "2"
            },
            "n3": {
                "name": "待跟进",
                "number": "6",
                "type": "3"
            },
            "n4": {
                "name": "超时未响应",
                "number": "6",
                "type": "4"
            }

        }

        return result
        # 第一组信息

    @http.route('/web/todesk2/todeskcontrller2', type='json', auth="user", methods=['POST'])
    def todeskcontrller2(self, **kwargs):
        # 获取头部信息
        Sql = ''
        sql_union = " UNION "
        Sql_begin = "SELECT name,number,TYPE FROM ( "
        Sql_1 = "SELECT '消息' as \"name\",COUNT(*) as \"number\",'1' as \"type\" FROM crm_lead WHERE type='lead'"
        Sql_2 = "SELECT '待处理' as \"name\",COUNT(*) as \"number\",'2' as \"type\" FROM crm_lead WHERE type='lead' or type='opportunity'"
        Sql_3 = "SELECT '待跟进' as \"name\",COUNT(*) as \"number\",'3' as \"type\" FROM sale_order"
        Sql_4 = "SELECT '超时未响应' as \"name\",COUNT(*) as \"number\",'4' as \"type\" FROM crm_lead_line"
        Sql_end = " ) T"
        Sql = f"{Sql_begin}{Sql_1}{sql_union}{Sql_2}{sql_union}{Sql_3}{sql_union}{Sql_4}{Sql_end}"
        # print(Sql)
        request.env.cr.execute(Sql)
        # result=request.cr.fetchall()
        result = {'n' + r['type']: r for r in request.cr.dictfetchall()}

        # 获取列表信息
        SqlList = "SELECT id,name,to_char(create_date, 'yyyy-mm-dd hh:mm:ss') as \"date\" FROM crm_lead WHERE type='lead' ORDER BY  create_date DESC LIMIT 5"
        # print(Sql)
        request.env.cr.execute(SqlList)
        resultList = request.cr.dictfetchall()
        # print(resultList)
        result['n0'] = resultList
        # print(resultList)
        # 状态码
        result['code'] = 200
        # print(result)
        return result

    @http.route('/web/todesk2/todeskcontrller3', type='json', auth="user", methods=['POST'])
    def todeskcontrller3(self, **kwargs):

        Sql = ''
        sql_union = " UNION "
        Sql_begin = "SELECT name,sum(\"number\") as \"number\",TYPE FROM ( "
        Sql_end = " ) T GROUP BY name,type ORDER BY type"
        # 1漏斗
        Sql_1 = "SELECT '询盘数' as \"name\",COUNT(*) as \"number\",'0' as \"type\" FROM crm_lead WHERE type='lead'"
        Sql_2 = "SELECT '报价单' as \"name\",COUNT(*) as \"number\",'1' as \"type\" FROM sale_order"
        Sql_3 = "SELECT '商机单' as \"name\",COUNT(*) as \"number\",'2' as \"type\" FROM crm_lead WHERE type='opportunity'"
        Sql_4 = "SELECT '合同数' as \"name\",COUNT(*) as \"number\",'3' as \"type\" FROM contract_contract"
        Sql = f"{Sql_begin}{Sql_1}{sql_union}{Sql_2}{sql_union}{Sql_3}{sql_union}{Sql_4}{Sql_end}"
        # print(Sql)
        request.env.cr.execute(Sql)
        result = {'n' + r['type']: r for r in request.cr.dictfetchall()}
        # print(result)
        # 2 报价-----------------------------------------------------
        Sql = ''
        Sql_1 = "SELECT '待下发' AS \"name\",COUNT ( * ) AS \"number\",'1' AS \"type\" FROM sale_order_pro_line WHERE push_status='0'"
        Sql_2 = "SELECT '待接收' AS \"name\",COUNT ( * ) AS \"number\",'2' AS \"type\" FROM sale_order_pro_line WHERE push_status='0'"
        Sql_3 = "SELECT '后道驳回' AS \"name\",COUNT ( * ) AS \"number\",'3' AS \"type\" FROM sale_order_pro_line WHERE push_status='0'"
        Sql_4 = "SELECT '后道处理' AS \"name\",COUNT ( * ) AS \"number\",'4' AS \"type\" FROM sale_order_pro_line WHERE push_status='0'"
        Sql_5 = "SELECT '业务审核' AS \"name\",COUNT ( * ) AS \"number\",'5' AS \"type\" FROM sale_order_pro_line WHERE push_status='0'"
        Sql_6 = "SELECT '主管审核' AS \"name\",COUNT ( * ) AS \"number\",'6' AS \"type\" FROM sale_order_pro_line WHERE push_status='0'"
        Sql_7 = "SELECT '发送报价' AS \"name\",COUNT ( * ) AS \"number\",'7' AS \"type\" FROM sale_order_pro_line WHERE push_status='0'"
        Sql_8 = "SELECT '等待反馈' AS \"name\",COUNT ( * ) AS \"number\",'8' AS \"type\" FROM sale_order_pro_line WHERE push_status='0'"
        Sql = f"{Sql_begin}{Sql_1}{sql_union}{Sql_2}{sql_union}{Sql_3}{sql_union}{Sql_4}{sql_union}{Sql_5}{sql_union}{Sql_6}{sql_union}{Sql_7}{sql_union}{Sql_8}{Sql_end}"
        # print(Sql)
        request.env.cr.execute(Sql)
        resultList = request.cr.dictfetchall()
        # print(resultList)
        result['n4'] = resultList
        # print(result)
        # 打样------------------------------------------------------
        Sql = ''
        Sql_1 = "SELECT '待下发' AS \"name\",COUNT ( * ) AS \"number\",'10' AS \"type\" FROM crm_lead_line WHERE need_type = '0' AND current_state='0'"
        Sql_2 = "SELECT '待接收' AS \"name\",COUNT ( * ) AS \"number\",'11' AS \"type\" FROM crm_lead_line WHERE need_type = '0' AND current_state='1'"
        Sql_3 = "SELECT '采购驳回' AS \"name\",COUNT ( * ) AS \"number\",'12' AS \"type\" FROM crm_lead_line WHERE need_type = '0' AND current_state='2'"
        Sql_4 = "SELECT '采购确认' AS \"name\",COUNT ( * ) AS \"number\",'13' AS \"type\" FROM crm_lead_line WHERE need_type = '0' AND current_state='6'"
        Sql_5 = "SELECT '分配工厂' AS \"name\",COUNT ( * ) AS \"number\",'14' AS \"type\" FROM crm_lead_line WHERE need_type = '0' AND current_state='9'"
        Sql_6 = "SELECT '样品收到' AS \"name\",COUNT ( * ) AS \"number\",'15' AS \"type\" FROM crm_lead_line WHERE need_type = '0' AND current_state='11'"
        Sql_7 = "SELECT '打样间打样' AS \"name\",COUNT ( * ) AS \"number\",'16' AS \"type\" FROM crm_lead_line WHERE need_type = '0' AND current_state='10'"
        Sql_8 = "SELECT '采购确认' AS \"name\",COUNT ( * ) AS \"number\",'17' AS \"type\" FROM crm_lead_line WHERE need_type = '0' AND current_state='6'"
        Sql_9 = "SELECT '业务审核' AS \"name\",COUNT ( * ) AS \"number\",'18' AS \"type\" FROM crm_lead_line WHERE need_type = '0' AND current_state='12'"
        Sql_10 = "SELECT '等待寄样' AS \"name\",COUNT ( * ) AS \"number\",'19' AS \"type\" FROM crm_lead_line WHERE need_type = '0' AND current_state='13'"
        Sql_11 = "SELECT '等待反馈' AS \"name\",COUNT ( * ) AS \"number\",'20' AS \"type\" FROM crm_lead_line WHERE need_type = '0' AND current_state='2'"
        Sql = f"{Sql_begin}{Sql_1}{sql_union}{Sql_2}{sql_union}{Sql_3}{sql_union}{Sql_4}{sql_union}{Sql_5}{sql_union}{Sql_6}{sql_union}{Sql_7}{sql_union}{Sql_8}{sql_union}{Sql_9}{sql_union}{Sql_10}{sql_union}{Sql_11}{Sql_end}"
        # print(Sql)
        request.env.cr.execute(Sql)
        resultList = request.cr.dictfetchall()
        # print(resultList)
        result['n5'] = resultList
        # print(result)
        # 设计------------------------------------------------------
        Sql = ''
        Sql_1 = "SELECT '待下发' AS \"name\",COUNT ( * ) AS \"number\",'1' AS \"type\" FROM crm_lead_line WHERE need_type = '1' AND current_state='0'"
        Sql_2 = "SELECT '待接收' AS \"name\",COUNT ( * ) AS \"number\",'2' AS \"type\" FROM crm_lead_line WHERE need_type = '1' AND current_state='1'"
        Sql_3 = "SELECT '设计驳回' AS \"name\",COUNT ( * ) AS \"number\",'3' AS \"type\" FROM crm_lead_line WHERE need_type = '1' AND current_state='8'"
        Sql_4 = "SELECT '设计中' AS \"name\",COUNT ( * ) AS \"number\",'4' AS \"type\" FROM crm_lead_line WHERE need_type = '1' AND current_state='5'"
        Sql_5 = "SELECT '打样间打样' AS \"name\",COUNT ( * ) AS \"number\",'5' AS \"type\" FROM crm_lead_line WHERE need_type = '1' AND current_state='10'"
        Sql_6 = "SELECT '设计确认' AS \"name\",COUNT ( * ) AS \"number\",'6' AS \"type\" FROM crm_lead_line WHERE need_type = '1' AND current_state='7'"
        Sql_7 = "SELECT '业务审核' AS \"name\",COUNT ( * ) AS \"number\",'7' AS \"type\" FROM crm_lead_line WHERE need_type = '1' AND current_state='12'"
        Sql_8 = "SELECT '发送设计' AS \"name\",COUNT ( * ) AS \"number\",'8' AS \"type\" FROM crm_lead_line WHERE need_type = '1' AND current_state='13'"
        Sql_9 = "SELECT '等待反馈' AS \"name\",COUNT ( * ) AS \"number\",'9' AS \"type\" FROM crm_lead_line WHERE need_type = '1' AND current_state='2'"
        Sql = f"{Sql_begin}{Sql_1}{sql_union}{Sql_2}{sql_union}{Sql_3}{sql_union}{Sql_4}{sql_union}{Sql_5}{sql_union}{Sql_6}{sql_union}{Sql_7}{sql_union}{Sql_8}{sql_union}{Sql_9}{Sql_end}"
        # print(Sql)
        request.env.cr.execute(Sql)
        resultList = request.cr.dictfetchall()
        # print(resultList)
        result['n6'] = resultList
        # print(result)
        # 合同------------------------------------------------------
        Sql = ''
        Sql_1 = "SELECT '合同待提交' AS \"name\",COUNT ( * ) AS \"number\",'10' AS \"type\" FROM contract_contract WHERE contract_status = 'draft'"
        Sql_2 = "SELECT '合同审批中' AS \"name\",COUNT ( * ) AS \"number\",'11' AS \"type\" FROM contract_contract WHERE contract_status = 'approve'"
        Sql_3 = "SELECT '合同传NC' AS \"name\",COUNT ( * ) AS \"number\",'12' AS \"type\" FROM contract_contract WHERE contract_status = 'proceed'"
        Sql_4 = "SELECT '印刷品交接' AS \"name\",COUNT ( * ) AS \"number\",'13' AS \"type\" FROM performance_contract WHERE actual_customer_sign IS NOT NULL"
        Sql_5 = "SELECT '产前样' AS \"name\",COUNT ( * ) AS \"number\",'14' AS \"type\" FROM performance_contract WHERE actual_pre_product_sample IS NOT NULL"
        Sql_6 = "SELECT '生产上线' AS \"name\",COUNT ( * ) AS \"number\",'15' AS \"type\" FROM performance_contract WHERE actual_production_launch IS NOT NULL"
        Sql_7 = "SELECT '大货样' AS \"name\",COUNT ( * ) AS \"number\",'16' AS \"type\" FROM performance_contract WHERE actual_bulk_sample IS NOT NULL"
        Sql_8 = "SELECT '大货照' AS \"name\",COUNT ( * ) AS \"number\",'17' AS \"type\" FROM performance_contract WHERE actual_bulk_photo IS NOT NULL"
        Sql_9 = "SELECT '出运安排' AS \"name\",COUNT ( * ) AS \"number\",'18' AS \"type\" FROM performance_contract WHERE actual_shipment IS NOT NULL"
        Sql_10 = "SELECT '已发货' AS \"name\",COUNT ( * ) AS \"number\",'19' AS \"type\" FROM performance_contract WHERE actual_delivery IS NOT NULL"
        Sql_11 = "SELECT '离岗确认' AS \"name\",COUNT ( * ) AS \"number\",'20' AS \"type\" FROM performance_contract WHERE actual_departure_confirmation IS NOT NULL"
        Sql_12 = "SELECT '客户签收' AS \"name\",COUNT ( * ) AS \"number\",'21' AS \"type\" FROM performance_contract WHERE actual_customer_sign IS NOT NULL"
        Sql = f"{Sql_begin}{Sql_1}{sql_union}{Sql_2}{sql_union}{Sql_3}{sql_union}{Sql_4}{sql_union}{Sql_5}{sql_union}{Sql_6}{sql_union}{Sql_7}{sql_union}{Sql_8}{sql_union}{Sql_9}{sql_union}{Sql_10}{sql_union}{Sql_11}{sql_union}{Sql_12}{Sql_end}"
        # print(Sql)
        request.env.cr.execute(Sql)
        resultList = request.cr.dictfetchall()
        # print(resultList)
        result['n7'] = resultList
        # print(result)
        # 状态码-----------------------------------------------------
        result['code'] = 200

        return result

    @http.route('/web/todesk2/todeskcontrller1', type='json', auth="user", methods=['POST'])
    def todeskcontrller1(self, **kwargs):
        Sql = ''
        sql_union = " UNION "
        Sql_begin = "SELECT name,sum(\"number\") as \"number\",TYPE FROM ( "
        Sql_1 = "SELECT '询盘待跟进' as \"name\",COUNT(*) as \"number\",'1' as \"type\" FROM crm_lead WHERE type='lead'"
        Sql_2 = "SELECT '超时未响应' as \"name\",COUNT(*) as \"number\",'2' as \"type\" FROM crm_lead WHERE type='lead' or type='opportunity'"
        Sql_3 = "SELECT '超时未响应' as \"name\",COUNT(*) as \"number\",'2' as \"type\" FROM sale_order"
        Sql_4 = "SELECT '打样待审核' as \"name\",COUNT(*) as \"number\",'3' as \"type\" FROM crm_lead_line"
        Sql_5 = "SELECT '打样被驳回' as \"name\",COUNT(*) as \"number\",'4' as \"type\" FROM crm_lead_line"
        Sql_6 = "SELECT '报价待审核' as \"name\",COUNT(*) as \"number\",'5' as \"type\" FROM sale_order_pro_line"
        Sql_7 = "SELECT '报价被驳回' as \"name\",COUNT(*) as \"number\",'6' as \"type\" FROM sale_order_pro_line"
        Sql_end = " ) T GROUP BY name,type ORDER BY type"
        Sql = f"{Sql_begin}{Sql_1}{sql_union}{Sql_2}{sql_union}{Sql_3}{sql_union}{Sql_4}{sql_union}{Sql_5}{sql_union}{Sql_6}{sql_union}{Sql_7}{Sql_end}"
        # print(Sql)
        request.env.cr.execute(Sql)
        # result=request.cr.fetchall()
        result = {'n' + r['type']: r for r in request.cr.dictfetchall()}
        # 求和
        sum = 0
        for term, nested_dict in result.items():
            for id, n in nested_dict.items():
                if id == 'number':
                    sum = sum + n
        # 合计
        result['n0'] = {'name': '待办', 'number': sum, 'type': '0'}
        # 状态码
        result['code'] = 200

        return result

    @http.route('/web/todesk2/todeskcontrller5', type='json', auth='user', methods=['POST'])
    def todeskcontrller5(self, date_str):
        start = date_str + ' 00:00:00'
        stop = date_str + ' 23:59:59'
        Sql = "SELECT id,name,to_char(start, 'hh24:MI') as \"start\",to_char(stop, 'hh24:MI') as \"stop\" FROM calendar_event WHERE start>='" + start + "' AND stop <='" + stop + "' AND user_id="+str(request.env.user.id) + "  LIMIT 4"
        print(Sql)
        request.env.cr.execute(Sql)
        resultList = request.cr.dictfetchall()
        print(resultList)
        result = {'n1': resultList, 'code': 200}
        print(result)
        return result
