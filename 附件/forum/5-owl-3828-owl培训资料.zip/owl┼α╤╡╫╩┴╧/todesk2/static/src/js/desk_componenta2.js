/** @odoo-module **/

import { Mutex } from "@web/core/utils/concurrency";
import { bus } from 'web.core';
import config from 'web.config';
//import StockInventoryModel from '@stock_barcode_x/models/stock_inventory_model';
import DeskEvent from '@todesk/events/desk_component_event2';
import { registry } from "@web/core/registry";
import { useService } from "@web/core/utils/hooks";
import { View } from "@web/views/view";

const { Component, onMounted, useRef, onWillStart, onWillUnmount, useSubEnv, useState} = owl;

/**
 * Main Component
 * Gather the line information.
 * Manage the scan and save process.
 */

class DeskComponent2 extends Component {
    //--------------------------------------------------------------------------
    // Lifecycle
    //--------------------------------------------------------------------------
    setup() {
    this.actionService = useService("action");
        this.rpc = useService('rpc');
        this.orm = useService('orm');
        //this.validateBUtton = useRef('button2');
        this.notification = useService('notification');
//        const model = this._getModel(this.props);
        useSubEnv({'model': new DeskEvent()});
        this._scrollBehavior = 'smooth';
        this.isMobile = config.device.isMobile;
        this.actionMutex = new Mutex();
        this.state = useState({
            data: {},
        })
        onWillStart(async () => {
            this.env.model.setData();
            this.env.model.on('history-back', this, () => this.env.config.historyBack());
            this.env.model.on('update', this, () => this.render(true));
            this.env.model.on('hide_button', this, this._disable_button);
        })
        onMounted(() => {
            bus.on('barcode_scanned', this, this._onBarcodeScanned);
            bus.on('exit', this, this.exit);
        });
        onWillUnmount(() => {
            bus.off('barcode_scanned', this, this._onBarcodeScanned);
            bus.on('exit', this, this.exit);
        });


    }
    _disable_button(){
        this.validateBUtton.el.classList.add("disabled");
    }
    _onBarcodeScanned(barcode) {
        this.env.model.getBarcode(barcode);
    }

    validate(ev){
        this.env.model._validate(ev)
    }
    get displayBarcodeLines() {
        return true
    }
    get displayPutInPackButton() {

        return true;
    }
    get lines() {
        return this.env.model.Grouplines
    }
    get packageLines(){
        return {}

    }
    async exit(ev) {
        //await this.env.model.save();
        this.env.config.historyBack();
    }
    _onNotification(notifParams) {
        const { message } = notifParams;
        delete notifParams.message;
        this.env.services.notification.add(message, notifParams);
    }
    _openModuleInstallation(module) {
        const contractDomain = [['id','in',[1, 3, 4]]];
        this.actionService.doAction({
            type: "ir.actions.act_window",
            name: 'to do taskwindow',
            res_model: "todo.task",
            views: [
                [false, "list"],
                [false, "form"],
            ],
            target: "new",//current
            //context,
            domain: contractDomain,
        });
    }
    get info(){
        return {
            'message': '坏件回退',
            'icon': 'tags',
            'warning': false
        }
   }

    async testGetServerInfo(){
        const result = await this.orm.call('todesk.order', 'getinfo', [])
        if (result.code == 211) {
            this.notification.add(result.message, { type: 'warning' });
        }else{
            this.notification.add('提交成功', { type: 'success' });
        }

        console.log(result)
    }

    async testGetServerInfo_controller(){
        const info = await this.rpc('/web/todesk/todeskcontrller', {});
        //this.updateLocationId(locationId);result
        console.log(info)
        this.notification.add(info, { type: 'success' });
        console.log('end--')
    }


    get info2(){
        const result = this.rpc('/web/todesk/todeskcontrller', {});
        console.log(result);
        result.then(res=>{
          //console.log(res);

         })

return  {
            'message': '坏件回退',
            'icon': 'tags',
            'warning': false
        }

   }

   _fuzhiclick()
   {
            var v1=document.querySelector('#td1').textContent;
//            document.querySelector('#td1').innerText="<a href='www.baidu.com'>8888</a>";
//            document.querySelector("#td1").innerHTML="<a href='www.baidu.com'>8888</a>";

            var a="<a class='fw-bold' href='#' t-on-click.prevent=\"() => this._openModuleInstallation('act_todo_task_win')\">11111</a>"
        document.querySelector("#td1").innerHTML=a;
        console.log(v1);
   }


}



DeskComponent2.template = 'todesk.Template2';
DeskComponent2.components = {
    View,
};
registry.category("actions").add("todesk_desk_action_a2", DeskComponent2);
//export default MainComponent;

