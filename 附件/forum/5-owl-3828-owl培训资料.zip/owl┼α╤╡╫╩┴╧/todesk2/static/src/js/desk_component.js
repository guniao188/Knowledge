/** @odoo-module **/

import { Mutex } from "@web/core/utils/concurrency";
import { bus } from 'web.core';
import config from 'web.config';
//import StockInventoryModel from '@stock_barcode_x/models/stock_inventory_model';
import DeskEvent from '@todesk2/events/desk_component_event';
import { registry } from "@web/core/registry";
import { useService } from "@web/core/utils/hooks";
import { View } from "@web/views/view";

import { ConfirmationDialog } from "@web/core/confirmation_dialog/confirmation_dialog";
import { TodeskProjectStopRecurrenceConfirmationDialog } from "@todesk2/dialog/project_stop_recurrence_confirmation_dialog";
import { _lt } from "@web/core/l10n/translation";
import { sprintf } from "@web/core/utils/strings";

const { Component, onMounted, useRef, onWillStart, onWillUnmount, useSubEnv, useState} = owl;

/**
 * Main Component
 * Gather the line information.
 * Manage the scan and save process.
 */

class DeskComponent extends Component {
    //--------------------------------------------------------------------------
    // Lifecycle
    //--------------------------------------------------------------------------
    setup() {
        this.dialogService = useService("dialog");
        this.actionService = useService("action");
        this.username='<b>123</b>'
        this.iframe = useRef('iframe1');
        this.rpc = useService('rpc');
        this.orm = useService('orm');
        this.notification = useService('notification');
        //const model = this._getModel(this.props);
        useSubEnv({'model': new DeskEvent()});
        this._scrollBehavior = 'smooth';
        this.isMobile = config.device.isMobile;
        this.actionMutex = new Mutex();
        this.state = useState({
            data: {},
        })
        //构造方法之后及DOM元素渲染之前
        onWillStart(async () => {
//            this.env.model.setData();
//            this.env.model.on('history-back', this, () => this.env.config.historyBack());
//            this.env.model.on('update', this, () => this.render(true));
//            this.env.model.on('hide_button', this, this._disable_button);
                var date = new Date();
                var year = date.getFullYear();
                var month = date.getMonth() + 1;
                var day = date.getDate(); //
                var dateStr=year.toString()+'-'+month.toString()+'-'+day.toString();
                console.log(dateStr);

                //通过路由方式获取后台数据
                await this._getinfo1();
                await this._getinfo2();
                await this._getinfo3();
                await this._getinfo5(dateStr,1);
                //通过ORM方式获取后台数据
                await this._getinfo_orm_call();
                await this._getinfo_orm_searchRead();

                console.log('later!')
        })
        //DOM元素渲染之后
        onMounted(() => {
            bus.on('barcode_scanned', this, this._onBarcodeScanned);
            bus.on('exit', this, this.exit);
//            bus.on('click', this, this._onChangeTaxValue);
            //监听iframe内子网页的click事件
            this.iframe.el.contentWindow.addEventListener("click", (ev) => {
                    this._getinfo5(document.querySelector("#rltext").value,2);
                     document.querySelector("#todaytitle").innerHTML='事项['+document.querySelector("#rltext").value+']';
                });
            //向外部暴露clickurl()方法，以方便iframe内的子网页能够使用该方法
            window.clickurl=this._clickurl;
        });
        //DOM元素卸载之后
        onWillUnmount(() => {
            bus.off('barcode_scanned', this, this._onBarcodeScanned);
            bus.off('exit', this, this.exit);
//            bus.off('click', this.iframe.el.contentWindow, this._onChangeTaxValue);
        });
    }


    _disable_button(){
        this.validateBUtton.el.classList.add("disabled");
    }
    _onBarcodeScanned(barcode) {
        this.env.model.getBarcode(barcode);
    }

    validate(ev){
        this.env.model._validate(ev)
    }
    get displayBarcodeLines() {
        return true
    }
    get displayPutInPackButton() {

        return true;
    }
    get lines() {
        return this.env.model.Grouplines
    }
    get packageLines(){
        return {}

    }
    async exit(ev) {
        //await this.env.model.save();
        this.env.config.historyBack();
    }
    _onNotification(notifParams) {
        const { message } = notifParams;
        delete notifParams.message;
        this.env.services.notification.add(message, notifParams);
    }
    _openModuleInstallation(module) {
        const contractDomain = [['id','in',[1, 3, 4]]];
        this.actionService.doAction({
            type: "ir.actions.act_window",
            name: module,
            res_model: "todesk.customer",
            views: [
                [false, "list"],
                [false, "form"],
            ],
            target: "new",//current
            //context,
            domain: contractDomain,
        });
    }
   async  _getinfo1()
   {
            const result =await this.rpc('/web/todesk2/todeskcontrller1', {});
            this.userinfolist1=result;
   }
    async  _getinfo2()
   {
            const result =await this.rpc('/web/todesk2/todeskcontrller2', {});
            this.userinfolist2=result;
   }
    async  _getinfo3()
   {
            const result =await this.rpc('/web/todesk2/todeskcontrller3', {});
            this.userinfolist3=result;
   }
    async  _getinfo4()
   {
            const result =await this.rpc('/web/todesk2/todeskcontrller4', {});
            this.userinfolist4=result;

   }
   async _getinfo5(datestr,type)
   {
            const result =await this.rpc('/web/todesk2/todeskcontrller5', {'date_str': datestr,});
            this.userinfolist5=result;
            console.log(result);
            if(type==2)
            {
                var outStr='<tr>';
                this.userinfolist5.n1.forEach(item => {
                    outStr=outStr+'<td>'+item.start+'至'+item.stop+'</td>'+'<td align=\"left\">'+item.name+'</td>'
                });
                if(outStr.length>10)
                {
                    outStr=outStr+'</tr>'
                    document.querySelector("#todayTodo").innerHTML=outStr;
                }
                else
                {
                    document.querySelector("#todayTodo").innerHTML='';
                }
                console.log('2');
            }
            console.log(outStr);

   }

   async  _getinfo_orm_call()
   {
       const returnValue = await this.orm.call(
                'todesk.customer',
                'get_customer',
                ['pa1','par2','par3']
            );
       console.log(returnValue)
   }

   async  _getinfo_orm_searchRead()
   {
     const domain = [
            ["name", "=", "wujian"],
        ];
     const fields = ["name", "code", "ip"];

     const returnValue = await this.orm.searchRead("todesk.customer",  domain, fields);
     console.log(returnValue)
   }








   _clickto(module,type)
   {
        const contractDomain = [['id','in',[1, 3, 4]]];
        const module2='to desk customer win'
        this.actionService.doAction({
            type: "ir.actions.act_window",
            name: module2,
            res_model: "todesk.customer",
            views: [
                [false, "list"],
                [false, "form"],
            ],
            target: "new",//current
            //context,
            domain: contractDomain,
        });
   }

   _quick1(type)
   {
        //const contractDomain = [['id','in',[1, 3, 4]]];
        const module2='to desk customer win'
        this.actionService.doAction({
            type: "ir.actions.act_window",
            name: module2,
            res_model: "todesk.customer",
            views: [
                [false, "form"],
            ],
            target: "new",//current
            //context,
           // domain: contractDomain,
        });
   }

       _clickurl(datestr)
        {
            //点击日历，调用该方法
            document.querySelector("#rltext").value=datestr;
        }
        _onChangeTaxValue() {
            console.log('wuwuwuwuwuwu');
        }

        async _openA() {
           const canProceed = await new Promise((resolve) => {
                this.dialogService.add(ConfirmationDialog, {
                    body: this.env._t("Are you sure you want to delete this shift?"),
                    cancel: () => resolve(false),
                    close: () => resolve(false),
                    confirm: () => resolve(true),
                });
            });
        };
        async _openDialogParent(){
                console.log("a");
                    await new Promise((resolve, reject) => {
                                const dialogProps = {
                                    title: _lt("选择框"),
                                    body: sprintf(
                                            '',
                                        this.parentName,
                                        this.parentString
                                    ),
                                    confirmLabel: _lt("Select"),
                                    list:[{"id": 10, "name": "Design Software Info", "memo": ""}, {"id": 4, "name": "Campbell: Chairs", "memo": ""}],
                                    selected: async(resId) => {
                                        console.log(resId);
                                        resolve(resId);
                                    },
                                    cancel: () => {},
                                };
                                this.dialogService.add(TodeskProjectStopRecurrenceConfirmationDialog, dialogProps);
                    });
                console.log("b");
        }




        _openDialog(){
            console.log("a");
            const dialogProps = {
                title: _lt("选择框"),
                body: sprintf(
                        '',
                    this.parentName,
                    this.parentString
                ),
                confirmLabel: _lt("Select"),
                list:[{"id": 10, "name": "Design Software Info", "memo": ""}, {"id": 4, "name": "Campbell: Chairs", "memo": ""}],
                selected: (resId) => {
                    console.log(resId);
                },
                cancel: () => {},
            };
            this.dialogService.add(TodeskProjectStopRecurrenceConfirmationDialog, dialogProps);

        }

}



DeskComponent.template = 'todesk.Template';
DeskComponent.components = {
    View,
};
registry.category("actions").add("todesk_desk_action", DeskComponent);
//export default MainComponent;

