/** @odoo-module **/

import {_t, _lt} from "web.core";
import { useService } from "@web/core/utils/hooks";
import { Mutex } from "@web/core/utils/concurrency";
//import LazyBarcodeCache from '@stock_barcode_x/lazy_barcode_cache';
const { EventBus, useState } = owl;

export default class DeskComponentEvent extends EventBus {
    constructor(params, services) {
        super();
        this.dialogService = useService('dialog');
        this.rpc = useService('rpc');
        this.orm = useService('orm');
        this.notification = useService('notification');
  
    }   
    get Grouplines(){
        return this.currentState.lines
    }
    setData() {
        this.actionMutex = new Mutex();
        this._createState();
    }
    
    async _validate(ev){
        const result = await this.orm.call('stock.picking', 'back_lines', [this.currentState.lines])
        if (result.code == 211) {
            this.notification.add(result.message, { type: 'warning' });
        }else{
            this.notification.add('提交成功', { type: 'success' });
            this.trigger('hide_button');
        }
    }
    getBarcode(barcode){
       
        //this.currentState.lines.push(result) 
        this.currentState.lines.push({
            'id': this.currentState.lines.length + 1,
            'name': barcode,
        })
        return this.trigger('update');
    }
    // Response -> UI State
    _createState() {
        const lines = []
        this.initialState = { lines };
        this.currentState = JSON.parse(JSON.stringify(this.initialState)); // Deep copy
    }
}