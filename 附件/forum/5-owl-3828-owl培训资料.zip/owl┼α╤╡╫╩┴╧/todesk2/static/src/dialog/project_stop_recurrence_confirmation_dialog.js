/** @odoo-module */

import { ConfirmationDialog } from '@web/core/confirmation_dialog/confirmation_dialog';

export class TodeskProjectStopRecurrenceConfirmationDialog extends ConfirmationDialog {
    _continueRecurrence() {
        if (this.props.continueRecurrence) {
            this.props.continueRecurrence();
        }
        this.props.close();
    }
    async _selected() {
        if (this.props.selected) {
            await this.props.selected(this.current);
        }
        this.props.close();
    }
    _tocheck(value){
        var number=this.props.list.length;
        this.current=null;
        var ids = document.getElementsByName("checkb");
        var i;
        for(i=0;i<ids.length;i++){
                if(ids[i].checked){
                    if(value==ids[i].value)
                    {
                        this.current=value;
                    }
                    else
                    {
                        ids[i].checked=false;
                    }

                }
        }
    }


    _tocheckhref(value){
         // t-ref="iframe1"
         //this.current=value;
         this.current=null;
        var ids = document.getElementsByName("checkb");
        var i;
        for(i=0;i<ids.length;i++){
                if(value==ids[i].value)
                {
                    ids[i].checked=true;
                    this.current=value;
                }
                else
                {
                    ids[i].checked=false
                }
            }
    }


}
TodeskProjectStopRecurrenceConfirmationDialog.template = 'Todesk2.ProjectStopRecurrenceConfirmationDialog';
TodeskProjectStopRecurrenceConfirmationDialog.props.continueRecurrence = { type: Function, optional: true };
TodeskProjectStopRecurrenceConfirmationDialog.props.selected = { type: Function, optional: true };
TodeskProjectStopRecurrenceConfirmationDialog.props.list={ type: Object, optional: true };
