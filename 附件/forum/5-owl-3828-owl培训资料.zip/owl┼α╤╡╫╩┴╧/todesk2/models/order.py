from odoo import api, fields, models


class TodeskOrder(models.Model):
    _name = 'todesk.order'

    code = fields.Char(string='订单编号')
    name = fields.Char(string='订单名称')
    xddate = fields.Datetime(string='下单日期')
    customer_id = fields.Many2one('todesk.customer', string='所属客户')

    @api.model
    def getinfo(self):
        str= self._outinfo()
        return {'code': 211, 'message': '后台返回信息'+str}

    def _outinfo(self):
        return '11'
