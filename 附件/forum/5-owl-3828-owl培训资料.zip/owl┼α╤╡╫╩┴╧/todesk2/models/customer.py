from odoo import api, fields, models


class TodeskManager(models.Model):
    _name = 'todesk.customer'

    code = fields.Char(string='来访编号')
    name = fields.Char(string='来访名称')
    ip = fields.Char(string='ip地址')
    address = fields.Char(string='归属地')
    datetest = fields.Datetime(string='日期')

    @api.model
    def get_customer(self, par1, par2, par3):
        return 'return_value_get_customer:' + par1 + par2 + par3


class LeadLine(models.Model):
    _name = "crm.lead.line"
    _description = "crm_lead_line"

    name = fields.Integer('商机编码')
    lead_code = fields.Char(string="商机编码")
    current_state = fields.Selection(
        [('0', '待下发'),
         ('1', '待接收'),
         ('2', '待反馈'),
         ('3', '已归档'),
         ('4', '已作废'),
         ('5', '设计中'),
         ('6', '采购确认'),
         ('7', '设计确认'),
         ('8', '设计驳回'),
         ('9', '分配工厂'),
         ('10', '打样间打样'),
         ('11', '样品收到'),
         ('12', '业务审核'),
         ('13', '等待寄样'),
         ], '当前阶段', default="0")
    need_type = fields.Selection([('0', '直接要样'), ('1', '设计要样')], '需求类型', default="0", required=True)


class OrderProLine(models.Model):
    _name = "sale.order.pro.line"
    _description = "sale_order_pro_line"

    product_name = fields.Char(string="产品名称", store=True)
    product_code = fields.Char(string="产品编码", store=True, required=True)
    push_status = fields.Selection(
        [
            ('0', '未推送'),
            ('1', '未反馈'),
            ('2', '已确认'),
            ('3', '待审核'),
            ('4', '已驳回'),
        ],
        '状态', default="0")


class ContractContract(models.Model):
    _name = "contract.contract"
    _description = "contract_contract"

    product_name = fields.Char(string="合同名称", store=True)
    product_code = fields.Char(string="合同编码", store=True, required=True)
    contract_status = fields.Selection(
        [('draft', '新建'), ('approve', '审核'), ('proceed', '进行中'), ('changing', '变更中'), ('archive', '归档')],
        string='状态',
        default='draft')


class ContractContractLine(models.Model):
    _name = "contract.contract.line"
    _description = "contract_contract_line"

    product_name = fields.Char(string="合同明细", store=True)
    product_code = fields.Char(string="合同编码", store=True, required=True)


class clsMenu(models.Model):
    _name = 'performance.contract'
    _description = 'performance.contract'
    actual_production_launch = fields.Datetime('Actual Production Launch Time', store="true")  # 实际生成上线时间*
    actual_production_completed = fields.Datetime('Actual Production Completed Time', store="true")  # 实际生产完成时间*
    actual_shipment = fields.Datetime('Actual Shipment Time', store="true")  # 实际出运安排时间*
    actual_delivery = fields.Datetime('Actual Delivery Time', store="true")  # 实际发货时间*
    actual_departure_confirmation = fields.Datetime('Actual Departure Confirmation Time', store="true")  # 实际离港时间*
    actual_customer_sign = fields.Datetime('Actual customer signing time', store="true")  # 实际客户签收时间*

    actual_pre_product_sample = fields.Datetime('Actual Pre Product Sample Time', store="true")  # 实际产前样时间*
    actual_bulk_sample = fields.Datetime('Actual Bulk Sample Time', store="true")  # 实际大货样时间*
    actual_bulk_photo = fields.Datetime('Actual Bulk Photo Time', store="true")  # 实际大货照时间*

    contract_sign_time = fields.Datetime('Contract Signing Time')  # 合同签订时间*
    order_issuance_time = fields.Datetime('Purchase Order Issuance Time')  # 采购单下发时间*
    print_confirmation_time = fields.Datetime('Print Confirmation Time')  # 印刷品交接时间*
