# -*- coding: utf-8 -*-
from . import product_category
from . import product_template
from . import stock_move
from . import stock_valuation_layer
from . import stock_lot
from . import stock_quant
from . import product_product