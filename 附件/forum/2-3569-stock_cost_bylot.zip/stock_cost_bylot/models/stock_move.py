# -*- coding: utf-8 -*-
from odoo import api, fields, models, _, tools
from odoo.exceptions import ValidationError
from odoo.exceptions import UserError
from odoo.tools.float_utils import float_compare, float_round, float_is_zero
import logging

_logger = logging.getLogger(__name__)

class StockMove(models.Model):
    _inherit = 'stock.move'

    def _create_in_svl(self, forced_quantity=None):
        SVL = self.env['stock.valuation.layer']
        super_self = self.filtered(lambda s: not s.product_id.value_tracking_bylot)
        this_self = self.filtered(lambda s: s.product_id.value_tracking_bylot)
        SVL |= super(StockMove, super_self)._create_in_svl(forced_quantity=forced_quantity)

        svl_vals_list = []
        for move in this_self:
            move = move.with_company(move.company_id)
            valued_move_lines = move._get_in_move_lines()
            valued_quantity = 0
            for valued_move_line in valued_move_lines:
                valued_quantity = valued_move_line.product_uom_id._compute_quantity(valued_move_line.qty_done, move.product_id.uom_id)
                unit_cost = abs(move._get_price_unit())  # May be negative (i.e. decrease an out move).
                svl_vals = move.product_id._prepare_in_svl_vals(forced_quantity or valued_quantity, unit_cost)
                # SVL上增加批次号
                if not valued_move_line.lot_id:
                    raise ValidationError("勾选了基于批次个别计价的产品，必须设置批次管理，入库出库必须有批次！")
                svl_vals['lot_id'] = valued_move_line.lot_id.id
                svl_vals.update(move._prepare_common_svl_vals())
                if forced_quantity:
                    svl_vals['description'] = 'Correction of %s (modification of past move)' % move.picking_id.name or move.name
                svl_vals_list.append(svl_vals)

        SVL |= self.env['stock.valuation.layer'].sudo().create(svl_vals_list)
        return SVL

    def _create_out_svl(self, forced_quantity=None):
        SVL = self.env['stock.valuation.layer']
        super_self = self.filtered(lambda s: not s.product_id.value_tracking_bylot)
        this_self = self.filtered(lambda s: s.product_id.value_tracking_bylot)
        SVL |= super(StockMove, super_self)._create_out_svl(forced_quantity=forced_quantity)

        svl_vals_list = []
        for move in this_self:
            move = move.with_company(move.company_id)
            valued_move_lines = move._get_out_move_lines()
            valued_quantity = 0
            for valued_move_line in valued_move_lines:
                valued_quantity = valued_move_line.product_uom_id._compute_quantity(valued_move_line.qty_done, move.product_id.uom_id)
                if float_is_zero(forced_quantity or valued_quantity, precision_rounding=move.product_id.uom_id.rounding):
                    continue
                # 按批次号出货
                if not valued_move_line.lot_id:
                    raise ValidationError("勾选了基于批次个别计价的产品，必须设置批次管理，入库出库必须有批次！")
                svl_vals = move.product_id.with_context(value_tracking_lot=valued_move_line.lot_id)._prepare_out_svl_vals(forced_quantity or valued_quantity, move.company_id)
                svl_vals.update(move._prepare_common_svl_vals())
                svl_vals['lot_id'] = valued_move_line.lot_id.id
                if forced_quantity:
                    svl_vals['description'] = 'Correction of %s (modification of past move)' % move.picking_id.name or move.name
                svl_vals['description'] += svl_vals.pop('rounding_adjustment', '')
                svl_vals_list.append(svl_vals)

        SVL |= self.env['stock.valuation.layer'].sudo().create(svl_vals_list)
        return SVL
