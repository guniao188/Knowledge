# -*- coding: utf-8 -*-
from odoo import api, fields, models, _, tools
import logging

_logger = logging.getLogger(__name__)


class StockValuationLayer(models.Model):
    _inherit = 'stock.valuation.layer'

    lot_id = fields.Many2one('stock.lot', 'Lot', check_company=True)
    