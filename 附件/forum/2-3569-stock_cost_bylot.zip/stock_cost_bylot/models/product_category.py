# -*- coding: utf-8 -*-
from odoo import api, fields, models, _, tools
import logging

_logger = logging.getLogger(__name__)


class ProductCategory(models.Model):
    _inherit = 'product.category'

    value_tracking_bylot = fields.Boolean('批次个别计价法', company_dependent=True)

    @api.onchange('value_tracking_bylot')
    def onchange_from_value_tracking_bylot(self):
        if self.value_tracking_bylot:
            self.property_cost_method = 'fifo'
