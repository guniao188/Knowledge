# -*- coding: utf-8 -*-
from odoo import api, fields, models, _, tools
import logging

_logger = logging.getLogger(__name__)


class ProudctTemplate(models.Model):
    _inherit = 'product.template'

    value_tracking_bylot = fields.Boolean(related='categ_id.value_tracking_bylot')
    