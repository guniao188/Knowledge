# -*- coding: utf-8 -*-
{
    'name': "基于批次的个别计价法",
    'author': "OSCG",
    'website': "http://www.oscg.cn",
    'category': 'Hidden',
    'version': '15.0.1',
    'depends': [
       'stock_account',
    ],
    'data': [
        'views/product_category.xml',
        'views/stock_valuation_layer.xml',
    ],
    'installable': True,
    'application': False,
    'auto_install': False,
}